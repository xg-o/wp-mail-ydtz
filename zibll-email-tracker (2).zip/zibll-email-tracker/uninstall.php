<?php
/**
 * 卸载脚本：仅清理插件配置与缓存。
 * 出于安全考虑，不自动删除用户数据（追踪记录文件 / 数据表），
 * 如需彻底清理，请在卸载前到「邮件追踪 → 打开记录」点「清空记录」，
 * 或在数据库中手动 DROP TABLE。如需自动删表，取消下面注释即可。
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// 1. 删除设置项
delete_option( 'zet_settings' );

// 2. 删除相关 transient（token 关联信息 + geo 缓存）
global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_zet_%' OR option_name LIKE '_transient_timeout_zet_%'" );

// 3. 清除定时任务
wp_clear_scheduled_hook( 'zet_daily_purge' );
wp_clear_scheduled_hook( 'zet_daily_purge' );

/*
// 4. 如需连数据表一并删除，取消以下注释：
$table = $wpdb->prefix . 'zet_email_track';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
*/
