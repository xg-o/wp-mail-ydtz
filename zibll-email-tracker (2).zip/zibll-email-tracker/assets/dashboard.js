/* 子比主题邮件追踪 · 打开记录大屏 交互
 * 兼容桌面（右侧滑出抽屉）与手机（底部上滑面板）。
 */
(function () {
  var D = window.ZET_DATA || { rows: [], tokens: {}, spark: [] };
  function el(h) { var t = document.createElement('template'); t.innerHTML = h.trim(); return t.content.firstChild; }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function dash(v) { return (v === '' || v == null) ? '—' : v; }

  /* 迷你柱状图 */
  document.querySelectorAll('.zet-spark').forEach(function (s) {
    var bars = (s.getAttribute('data-bars') || '').split(',').map(Number);
    var max = Math.max.apply(null, bars.concat([1]));
    bars.forEach(function (b, i) {
      var i2 = document.createElement('i');
      i2.style.height = Math.max(2, b / max * 100) + '%';
      if (i >= bars.length - 2) i2.style.background = 'var(--accent)';
      s.appendChild(i2);
    });
  });

  var list = document.getElementById('zet-list');
  var countEl = document.getElementById('zet-count');
  if (!list) return;

  /* 渲染行 */
  D.rows.forEach(function (r, i) {
    var n = r.opens || 1;
    var row = el(
      '<div class="zet-row" data-i="' + i + '" data-ts="' + (r.ts || 0) + '" data-token="' + esc(r.token) + '" tabindex="0" role="button">' +
        '<div class="zt">' + esc(r.t) + '</div>' +
        '<div class="zto">' + esc(dash(r.to)) + '</div>' +
        '<div class="zsubj">' + esc(dash(r.subj)) + '</div>' +
        '<div class="zip">' + esc(dash(r.ip)) + '<span class="zloc">' + esc(r.loc || '') + '</span></div>' +
        '<div class="ztags"><span class="zet-tag" title="' + esc(dash(r.dev)) + '">' + esc(dash(r.dev)) + '</span><span class="zet-tag" title="' + esc(dash(r.os)) + '">' + esc(dash(r.os)) + '</span><span class="zet-tag" title="' + esc(dash(r.br)) + '">' + esc(dash(r.br)) + '</span></div>' +
        '<div class="zet-openc">' + (r.type === 'click' ? '<span class="zet-badge" style="background:#fff3e0;color:#b26a00">🔗 点击</span>' : '<span class="zet-badge' + (n > 1 ? ' multi' : '') + '">' + n + ' 次</span>') + '</div>' +
      '</div>');
    list.appendChild(row);
  });

  if (!D.rows.length) {
    list.appendChild(el('<div class="zet-empty">暂无记录。发送一封 HTML 邮件，收件人允许加载图片后即可看到。</div>'));
  }

  /* 抽屉 */
  var mask = document.getElementById('zet-mask'), drawer = document.getElementById('zet-drawer');
  var prevOverflow = '';
  function lockScroll(on) {
    if (on) { prevOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden'; }
    else { document.body.style.overflow = prevOverflow || ''; }
  }
  function openDetail(idx) {
    var r = D.rows[idx]; if (!r) return;
    var o = D.tokens[r.token] || [];
    if (!o.length) o = [{ t: r.t, ip: r.ip, loc: r.loc, dev: r.dev, os: r.os, br: r.br }];
    document.getElementById('zet-d-subj').textContent = r.subj || '(无主题)';
    document.getElementById('zet-d-to').textContent = '收件人 ' + (r.to || '—') + ' · 最近记录 ' + r.t;
    document.getElementById('zet-d-count').textContent = o.length;
    document.getElementById('zet-d-first').textContent = (o[0].t || '').replace(/^\d{4}-/, '');
    document.getElementById('zet-d-last').textContent = (o[o.length - 1].t || '').replace(/^\d{4}-/, '');
    var tl = document.getElementById('zet-d-tl'); tl.innerHTML = '';
    o.forEach(function (e, i) {
      tl.appendChild(el(
        '<div class="zet-ev"><div class="zet-eh"><span class="zet-et">' + (e.type === 'click' ? '点击链接' : '第 ' + (i + 1) + ' 次打开') + '</span><span class="zet-ew">' + esc(e.t) + '</span></div>' +
        '<div class="zet-ed"><code>' + esc(dash(e.ip)) + '</code>' + (e.loc ? ' · ' + esc(e.loc) : '') + '</div>' +
        '<div class="zet-ed">' + esc(dash(e.dev)) + ' / ' + esc(dash(e.os)) + ' / ' + esc(dash(e.br)) + '</div></div>'));
    });
    mask.classList.add('on'); drawer.classList.add('on');
    lockScroll(true);
  }
  function closeDetail() { mask.classList.remove('on'); drawer.classList.remove('on'); lockScroll(false); }
  list.addEventListener('click', function (e) {
    var row = e.target.closest('.zet-row'); if (!row || row.classList.contains('zet-head')) return;
    openDetail(parseInt(row.getAttribute('data-i'), 10));
  });
  list.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    var row = e.target.closest && e.target.closest('.zet-row'); if (!row || row.classList.contains('zet-head')) return;
    e.preventDefault(); openDetail(parseInt(row.getAttribute('data-i'), 10));
  });
  var x = document.getElementById('zet-close'); if (x) x.addEventListener('click', closeDetail);
  if (mask) mask.addEventListener('click', closeDetail);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDetail(); });

  /* 搜索 + 时间筛选（前端） */
  var q = document.getElementById('zet-q');
  var chips = document.getElementById('zet-chips');
  var activeDays = 7;
  function apply() {
    var kw = (q ? q.value : '').trim().toLowerCase();
    var now = Math.floor(Date.now() / 1000);
    var shown = 0;
    document.querySelectorAll('#zet-list .zet-row').forEach(function (row) {
      if (row.classList.contains('zet-head')) return;
      var ts = parseInt(row.getAttribute('data-ts'), 10) || 0;
      var okTime = activeDays === 0 ? true : (now - ts <= activeDays * 86400);
      var okKw = !kw || row.textContent.toLowerCase().indexOf(kw) > -1;
      row.style.display = (okTime && okKw) ? '' : 'none';
      if (okTime && okKw) shown++;
    });
    if (countEl) countEl.textContent = '显示 ' + shown + ' 条';
  }
  if (q) q.addEventListener('input', apply);
  if (chips) chips.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    chips.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
    b.classList.add('on');
    activeDays = parseInt(b.getAttribute('data-days'), 10) || 0;
    apply();
  });

  /* 首屏默认按 7 天筛选 */
  apply();
})();
