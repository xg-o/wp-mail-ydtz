<?php
/**
 * 地理位置解析：支持三种来源。
 *   - off      ：不获取归属地
 *   - builtin  ：插件内置（开箱即用，默认走 ip-api.com 免费接口，无需配置）
 *   - api      ：使用配置的接口，可选「预设」服务商，或「自定义」URL 模板 + 字段路径
 *
 * 预设：ipapi(ip-api.com) / ipinfo.io / 淘宝IP / 高德
 * 自定义：URL 模板含 {ip}、{key} 占位；用点号路径从返回 JSON 中取字段。
 *
 * 结果做缓存：成功 24h，失败 5min。可被 zet_geo_result 过滤器覆盖。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Geo {

	/** 预设服务商定义 */
	public static function providers() {
		return array(
			'ipapi'  => array(
				'label'  => 'ip-api.com（免费，无需 Key）',
				'url'    => 'http://ip-api.com/json/{ip}?lang=zh-CN&fields=status,country,regionName,city,isp',
				'key'    => false,
				'fields' => array( 'country' => 'country', 'region' => 'regionName', 'city' => 'city', 'isp' => 'isp' ),
			),
			'ipinfo' => array(
				'label'  => 'ipinfo.io（需 Token）',
				'url'    => 'https://ipinfo.io/{ip}/json?token={key}',
				'key'    => true,
				'fields' => array( 'country' => 'country', 'region' => 'region', 'city' => 'city', 'isp' => 'org' ),
			),
			'taobao' => array(
				'label'  => '淘宝 IP（需 accessKey）',
				'url'    => 'https://ip.taobao.com/outGetIpInfo?ip={ip}&accessKey={key}',
				'key'    => true,
				'fields' => array( 'country' => 'data.country', 'region' => 'data.region', 'city' => 'data.city', 'isp' => 'data.isp' ),
			),
			'gaode'  => array(
				'label'  => '高德地图（需 Key）',
				'url'    => 'https://restapi.amap.com/v3/ip?ip={ip}&key={key}',
				'key'    => true,
				'fields' => array( 'country' => '', 'region' => 'province', 'city' => 'city', 'isp' => '' ),
			),
			'custom' => array(
				'label'  => '自定义接口',
				'url'    => '',
				'key'    => false,
				'fields' => array( 'country' => 'country', 'region' => 'region', 'city' => 'city', 'isp' => 'isp' ),
			),
		);
	}

	public static function lookup( $ip ) {
		$s    = zet_get_option();
		$mode = isset( $s['geo_mode'] ) ? $s['geo_mode'] : 'builtin';

		if ( 'off' === $mode ) {
			return '';
		}

		$ip = trim( (string) $ip );
		if ( '' === $ip || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return '';
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return '内网/保留地址';
		}

		$providers = self::providers();

		if ( 'builtin' === $mode ) {
			$preset = 'ipapi';
			$url    = $providers['ipapi']['url'];
			$key    = '';
			$paths  = $providers['ipapi']['fields'];
		} else {
			$preset = isset( $s['geo_preset'] ) ? $s['geo_preset'] : 'ipapi';
			$key    = isset( $s['geo_key'] ) ? $s['geo_key'] : '';
			if ( ! isset( $providers[ $preset ] ) ) {
				$preset = 'ipapi';
			}
			if ( 'custom' === $preset ) {
				$url   = isset( $s['geo_url'] ) ? $s['geo_url'] : '';
				$paths = isset( $s['geo_c_fields'] ) && is_array( $s['geo_c_fields'] ) ? $s['geo_c_fields'] : $providers['custom']['fields'];
			} else {
				$url   = $providers[ $preset ]['url'];
				$paths = $providers[ $preset ]['fields'];
			}
		}

		if ( '' === trim( $url ) ) {
			return '';
		}
		// 需要 Key 但未填，跳过
		if ( false !== strpos( $url, '{key}' ) && '' === trim( $key ) ) {
			return '';
		}

		$cache_key = 'zet_geo_' . md5( $preset . '|' . $ip );
		$cached    = get_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}

		$endpoint = str_replace(
			array( '{ip}', '{key}' ),
			array( rawurlencode( $ip ), rawurlencode( $key ) ),
			$url
		);

		$result = '';
		$resp   = wp_remote_get( $endpoint, array( 'timeout' => 4 ) );
		if ( ! is_wp_error( $resp ) ) {
			$body = wp_remote_retrieve_body( $resp );
			$data = json_decode( $body, true );
			if ( is_array( $data ) ) {
				$parts = array();
				if ( is_array( $paths ) ) {
					foreach ( array( 'country', 'region', 'city', 'isp' ) as $f ) {
						if ( isset( $paths[ $f ] ) && '' !== $paths[ $f ] ) {
							$v = self::dig( $data, $paths[ $f ] );
							if ( '' !== $v ) {
								$parts[] = $v;
							}
						}
					}
				}
				$result = trim( implode( ' ', array_filter( $parts ) ) );
			}
		}

		/** 允许自定义解析结果 */
		$result = apply_filters( 'zet_geo_result', $result, $ip, $preset );

		set_transient( $cache_key, $result, $result ? DAY_IN_SECONDS : 300 );

		return $result;
	}

	/** 按点号路径从数组中取值，如 data.city */
	private static function dig( $data, $path ) {
		$path = trim( (string) $path );
		if ( '' === $path ) {
			return '';
		}
		$cur = $data;
		foreach ( explode( '.', $path ) as $seg ) {
			if ( is_array( $cur ) && isset( $cur[ $seg ] ) ) {
				$cur = $cur[ $seg ];
			} else {
				return '';
			}
		}
		return is_scalar( $cur ) ? (string) $cur : '';
	}
}
