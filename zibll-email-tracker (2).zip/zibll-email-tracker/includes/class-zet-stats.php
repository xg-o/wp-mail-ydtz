<?php
/**
 * 发送计数：用于计算「打开率」。
 * 每次注入追踪像素（= 一次发送）时按天 +1；打开率 ≈ 有打开的邮件数 / 发送数。
 * 存储于 option zet_sent_daily（形如 {"2026-09-28": 12, ...}），保留最近约 200 天。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Stats {

	const OPT = 'zet_sent_daily';

	public static function bump_sent() {
		$data = get_option( self::OPT, array() );
		if ( ! is_array( $data ) ) {
			$data = array();
		}

		$tz    = wp_timezone();
		$now   = new DateTime( 'now', $tz );
		$today = $now->format( 'Y-m-d' );

		$data[ $today ] = isset( $data[ $today ] ) ? intval( $data[ $today ] ) + 1 : 1;

		// 清理 200 天前
		if ( count( $data ) > 220 ) {
			$cut = ( clone $now )->modify( '-200 days' )->format( 'Y-m-d' );
			foreach ( $data as $d => $n ) {
				if ( $d < $cut ) {
					unset( $data[ $d ] );
				}
			}
		}

		update_option( self::OPT, $data, false );
	}

	/** 最近 $days 天的发送总数（含今天） */
	public static function get_sent( $days = 7 ) {
		$days = max( 1, intval( $days ) );
		$data = get_option( self::OPT, array() );
		if ( ! is_array( $data ) || empty( $data ) ) {
			return 0;
		}

		$tz  = wp_timezone();
		$now = new DateTime( 'now', $tz );
		$cut = ( clone $now )->modify( '-' . ( $days - 1 ) . ' days' )->format( 'Y-m-d' );

		$sum = 0;
		foreach ( $data as $d => $n ) {
			if ( $d >= $cut ) {
				$sum += intval( $n );
			}
		}
		return $sum;
	}
}
