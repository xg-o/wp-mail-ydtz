<?php
/**
 * 核心追踪逻辑：
 *  - 发送邮件时（wp_mail 过滤器）注入 1×1 追踪像素
 *  - 收件人打开邮件加载图片时（GET /track/<token>.gif）抓取并记录信息
 *  - 输出 1×1 透明 GIF
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Tracker {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_rewrite' ) );
		add_action( 'init', array( $this, 'maybe_track' ), 1 ); // 尽早拦截追踪请求
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
		add_filter( 'wp_mail', array( $this, 'inject_pixel' ), 99 );

		// 定时清理过期记录
		add_action( 'zet_daily_purge', array( $this, 'daily_purge' ) );
	}

	/* ---------- 生命周期 ---------- */

	public static function activate() {
		ZET_Storage::ensure_table();
		$self = self::instance();
		$self->register_rewrite();
		if ( class_exists( 'ZET_Click' ) ) {
			ZET_Click::instance()->register_rewrite();
		}
		flush_rewrite_rules();
		if ( ! get_option( ZET_OPTION ) ) {
			add_option( ZET_OPTION, zet_defaults() );
		}
		if ( ! wp_next_scheduled( 'zet_daily_purge' ) ) {
			wp_schedule_event( time() + 3600, 'daily', 'zet_daily_purge' );
		}
	}

	public static function deactivate() {
		flush_rewrite_rules();
		wp_clear_scheduled_hook( 'zet_daily_purge' );
	}

	public function daily_purge() {
		$days = zet_get_option( 'keep_days' );
		ZET_Storage::purge_old( $days );
	}

	/* ---------- 路由 / 重写 ---------- */

	public function register_rewrite() {
		add_rewrite_rule( '^track/([A-Za-z0-9_\-]+)\.gif$', 'index.php?zet_t=$matches[1]', 'top' );
	}

	public function query_vars( $vars ) {
		$vars[] = 'zet_t';
		return $vars;
	}

	public function track_url( $token ) {
		$s = zet_get_option();
		if ( isset( $s['url_mode'] ) && 'query' === $s['url_mode'] ) {
			return add_query_arg( 'zet_t', $token, home_url( '/' ) );
		}
		return home_url( '/track/' . $token . '.gif' );
	}

	/* ---------- 注入像素 ---------- */

	public function inject_pixel( $args ) {
		$s = zet_get_option();
		if ( empty( $s['enabled'] ) || empty( $s['auto_inject'] ) ) {
			return $args;
		}

		$message = isset( $args['message'] ) ? (string) $args['message'] : '';
		if ( '' === $message ) {
			return $args;
		}

		// 仅对 HTML 邮件注入（纯文本邮件不注入）
		if ( false === stripos( $message, '<html' ) && false === stripos( $message, '<body' ) && false === stripos( $message, '<div' ) && false === stripos( $message, '<p' ) ) {
			return $args;
		}

		$to      = isset( $args['to'] ) ? ( is_array( $args['to'] ) ? implode( ',', $args['to'] ) : $args['to'] ) : '';
		$subject = isset( $args['subject'] ) ? $args['subject'] : '';
		$token   = $this->create_token( $to, $subject );
		$pixel   = $this->pixel_html( $token );

		// 链接点击追踪：改写正文外链（与像素共用同一 token）
		if ( class_exists( 'ZET_Click' ) ) {
			$message = ZET_Click::instance()->rewrite( $message, $to, $subject, $token );
		}

		$extra = $pixel;
		if ( ! empty( $s['notice_enable'] ) && '' !== trim( (string) $s['notice_text'] ) ) {
			$extra .= '<p style="margin:16px 0 0;font-size:12px;line-height:1.6;color:#8a8a8a;">' . esc_html( $s['notice_text'] ) . '</p>';
		}
		if ( false !== stripos( $message, '</body>' ) ) {
			$message = preg_replace( '/<\/body>/i', $extra . '</body>', $message, 1 );
		} else {
			$message .= $extra;
		}

		$args['message'] = $message;
		return $args;
	}

	public function pixel_html( $token ) {
		$url = $this->track_url( $token );
		return '<img src="' . esc_url( $url ) . '" width="1" height="1" alt="" '
			. 'style="display:block;width:1px;height:1px;border:0;outline:none;overflow:hidden;" />';
	}

	/** 为一次发送生成唯一 token，并缓存其关联信息（收件人/主题/时间），保留 60 天 */
	public function create_token( $to, $subject ) {
		$token = wp_generate_password( 20, false, false );
		if ( class_exists( 'ZET_Stats' ) ) {
			ZET_Stats::bump_sent();
		}
		set_transient(
			'zet_tk_' . $token,
			array(
				'to'      => $to,
				'subject' => $subject,
				'created' => current_time( 'mysql' ),
			),
			60 * DAY_IN_SECONDS
		);
		return $token;
	}

	/* ---------- 处理追踪请求 ---------- */

	public function maybe_track() {
		if ( empty( zet_get_option( 'enabled' ) ) ) {
			return;
		}
		if ( is_admin() ) {
			return;
		}

		$token = '';
		if ( isset( $_GET['zet_t'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$token = sanitize_text_field( wp_unslash( $_GET['zet_t'] ) ); // phpcs:ignore
		} else {
			$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
			if ( preg_match( '#/track/([A-Za-z0-9_\-]{6,64})\.gif#i', $uri, $m ) ) {
				$token = $m[1];
			}
		}

		if ( '' === $token || ! preg_match( '/^[A-Za-z0-9_\-]{6,64}$/', $token ) ) {
			return;
		}

		$this->record( $token );
		$this->output_gif();
	}

	private function record( $token ) {
		$s      = zet_get_option();
		$ip     = self::real_ip();
		$ua     = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 500 ) : ''; // phpcs:ignore
		$parsed = ZET_UA::parse( $ua );
		$fields = isset( $s['fields'] ) && is_array( $s['fields'] ) ? $s['fields'] : array();
		$meta   = get_transient( 'zet_tk_' . $token );
		$meta   = is_array( $meta ) ? $meta : array();
		$to     = isset( $meta['to'] ) ? $meta['to'] : '';

		// 黑白名单
		if ( class_exists( 'ZET_Guard' ) && ! ZET_Guard::allow( $to ) ) {
			return;
		}

		$comp     = ! empty( $s['features']['compliance'] );
		$anon_ip  = $comp && ! empty( $s['comp_ip_anon'] );
		$drop_ua  = $comp && ! empty( $s['comp_drop_ua'] );
		$drop_geo = $comp && ! empty( $s['comp_drop_geo'] );
		$geo      = '';
		$geo_mode = isset( $s['geo_mode'] ) ? $s['geo_mode'] : 'builtin';
		if ( ! $drop_geo && in_array( 'geo', $fields, true ) && 'off' !== $geo_mode ) {
			$geo = ZET_Geo::lookup( $ip );
		}

		$event = array(
			'token'     => $token,
			'type'      => 'open',
			'time'      => current_time( 'mysql' ),
			'timestamp' => time(),
			'to'        => $to,
			'subject'   => isset( $meta['subject'] ) ? $meta['subject'] : '',
			'ip'        => $anon_ip ? ZET_Guard::anon_ip( $ip ) : $ip,
			'geo'       => $geo,
			'device'    => $parsed['device'],
			'os'        => $parsed['os'],
			'browser'   => $parsed['browser'],
			'ua'        => $drop_ua ? '' : $ua,
			'referer'   => isset( $_SERVER['HTTP_REFERER'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_REFERER'] ), 0, 250 ) : '', // phpcs:ignore
		);

		/** 允许在写入前修改/拦截事件 */
		$event = apply_filters( 'zet_before_record', $event, $token );

		// 防刷限流
		$verdict = ZET_Guard::rate( $ip );
		if ( 'limited' === $verdict ) {
			ZET_Guard::log_suspect( 'open', $event, $ip, $ua );
			if ( 'block' === ( isset( $s['ratelimit_action'] ) ? $s['ratelimit_action'] : 'log' ) ) {
				return;
			}
		}

		ZET_Storage::save( $event );

		// 实时通知
		if ( class_exists( 'ZET_Notify' ) ) {
			ZET_Notify::dispatch( 'open', $event );
		}
	}

	/** 获取真实 IP（兼容 Cloudflare / 反代 / CDN） */
	public static function real_ip() {
		$keys = array(
			'HTTP_CF_CONNECTING_IP',
			'HTTP_TRUE_CLIENT_IP',
			'HTTP_X_REAL_IP',
			'HTTP_X_FORWARDED_FOR',
			'REMOTE_ADDR',
		);
		foreach ( $keys as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) { // phpcs:ignore
				$ip = trim( explode( ',', wp_unslash( $_SERVER[ $k ] ) )[0] ); // phpcs:ignore
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		return isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0'; // phpcs:ignore
	}

	/** 输出 1×1 透明 GIF（42 字节标准图），并禁止缓存 */
	private function output_gif() {
		$gif = base64_decode( 'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7' );
		if ( ! headers_sent() ) {
			nocache_headers();
			header( 'Content-Type: image/gif' );
			header( 'Content-Length: ' . strlen( $gif ) );
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
			header( 'Pragma: no-cache' );
			header( 'Expires: 0' );
			header( 'Access-Control-Allow-Origin: *' );
		}
		echo $gif; // phpcs:ignore
		exit;
	}
}
