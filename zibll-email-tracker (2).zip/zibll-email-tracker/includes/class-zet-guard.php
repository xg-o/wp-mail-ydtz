<?php
/**
 * 安全模块 v2.1：
 *  - 黑白名单：黑名单与白名单可【同时存在】。规则：黑名单优先（命中即不跟踪）；
 *    若白名单启用且名单非空，则仅跟踪命中白名单者。
 *  - 防刷限流：同 IP 在时间窗内超过阈值 → 判定「疑似刷流量」，写日志并（可选）拦截入库。
 *  - 合规模式（多选）：IP 匿名化 / 不记录原始 UA / 不记录地理位置。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Guard {

	/* ---------- 合规 ---------- */

	public static function anon_ip( $ip ) {
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
			return preg_replace( '/\.\d+$/', '.0', $ip );
		}
		if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
			$p = explode( ':', $ip );
			return implode( ':', array_slice( $p, 0, 4 ) ) . '::';
		}
		return $ip;
	}

	/* ---------- 黑白名单 ---------- */

	public static function allow( $to ) {
		$s = zet_get_option();
		if ( empty( $s['features']['whitelist'] ) ) {
			return true; // 黑白名单模块总开关未开
		}
		$to = trim( (string) $to );

		// 黑名单优先：命中即不跟踪
		if ( ! empty( $s['bl_enabled'] ) && self::match( $to, (array) $s['bl_roles'], (string) $s['bl_emails'] ) ) {
			return false;
		}

		// 白名单：启用且名单非空 → 仅跟踪命中者
		if ( ! empty( $s['wl_enabled'] ) ) {
			$wl_emails = trim( (string) $s['wl_emails'] );
			if ( '' !== $wl_emails || ! empty( $s['wl_roles'] ) ) {
				if ( ! self::match( $to, (array) $s['wl_roles'], $wl_emails ) ) {
					return false;
				}
			}
		}
		return true;
	}

	/** 判断收件人是否命中「邮箱/域名」或「用户角色」之一 */
	private static function match( $to, $roles, $emails ) {
		$emails = preg_split( '/[\s,]+/', (string) $emails );
		$emails = array_filter( array_map( 'trim', (array) $emails ) );
		if ( '' !== $to ) {
			foreach ( $emails as $item ) {
				if ( '' === $item ) {
					continue;
				}
				if ( '@' === $item[0] ) {
					if ( substr( $to, -strlen( $item ) ) === $item ) {
						return true;
					}
				} elseif ( strcasecmp( $item, $to ) === 0 ) {
					return true;
				}
			}
		}
		$roles = array_filter( array_map( 'strval', (array) $roles ) );
		if ( $roles && '' !== $to ) {
			$u = get_user_by( 'email', $to );
			if ( $u ) {
				foreach ( (array) $u->roles as $r ) {
					if ( in_array( $r, $roles, true ) ) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/* ---------- 限流 ---------- */

	public static function rate( $ip ) {
		$s = zet_get_option();
		if ( empty( $s['features']['ratelimit'] ) ) {
			return 'ok';
		}
		$limit = intval( isset( $s['ratelimit_per_ip'] ) ? $s['ratelimit_per_ip'] : 20 );
		$win   = intval( isset( $s['ratelimit_window'] ) ? $s['ratelimit_window'] : 3600 );
		if ( $limit <= 0 ) {
			return 'ok';
		}
		$key = 'zet_rl_' . md5( $ip );
		$n   = intval( get_transient( $key ) );
		$n++;
		set_transient( $key, $n, $win > 0 ? $win : 3600 );
		return ( $n > $limit ) ? 'limited' : 'ok';
	}

	/* ---------- 日志 ---------- */

	public static function log_suspect( $type, $event, $ip, $ua ) {
		$row = array(
			'time'   => current_time( 'mysql' ),
			'type'   => $type,
			'ip'     => $ip,
			'ua'     => $ua,
			'to'     => isset( $event['to'] ) ? $event['to'] : '',
			'reason' => '同一 IP 在时间窗内频繁触发（疑似刷流量）',
		);
		self::log( $row );
		if ( class_exists( 'ZET_Notify' ) ) {
			ZET_Notify::dispatch( 'ratelimit', array(
				'ip'     => $ip,
				'to'     => $row['to'],
				'time'   => $row['time'],
				'reason' => $row['reason'],
			) );
		}
	}

	public static function log( $row ) {
		$file = self::log_file();
		$dir  = dirname( $file );
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		@file_put_contents( $file, wp_json_encode( $row, JSON_UNESCAPED_UNICODE ) . "\n", FILE_APPEND | LOCK_EX );
	}

	public static function log_file() {
		$s = zet_get_option();
		$p = trim( (string) ( isset( $s['log_file'] ) ? $s['log_file'] : '' ) );
		if ( '' !== $p ) {
			return $p;
		}
		$up = wp_upload_dir();
		return trailingslashit( $up['basedir'] ) . 'zibll-email-tracker/guard.log';
	}
}
