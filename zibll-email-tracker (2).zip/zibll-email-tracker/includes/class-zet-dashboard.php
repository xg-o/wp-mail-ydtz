<?php
/**
 * 后台「打开记录」大屏（zread 风格）：
 *  - 概览统计（今日/近7日打开、独立收件人、打开率 + 迷你柱状图）
 *  - 记录流（打开事件表，支持前端搜索 / 时间筛选）
 *  - 单封打开明细（点击任意一行 → 右侧抽屉显示该邮件的多次打开时间轴）
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Dashboard {

	/** 事件时间戳（优先用 timestamp，否则按站点时区解析 time） */
	private static function ev_ts( $e ) {
		if ( isset( $e['timestamp'] ) && $e['timestamp'] ) {
			return intval( $e['timestamp'] );
		}
		$t = isset( $e['time'] ) ? $e['time'] : '';
		if ( '' === $t ) {
			return time();
		}
		try {
			$dt = new DateTime( $t, wp_timezone() );
			return $dt->getTimestamp();
		} catch ( Exception $ex ) {
			return strtotime( $t );
		}
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$s      = zet_get_option();
		$events = ZET_Storage::fetch( 3000 );

		$tz   = wp_timezone();
		$now  = new DateTime( 'now', $tz );
		$tk   = $now->format( 'Y-m-d' );
		$c7   = ( clone $now )->modify( '-6 days' )->format( 'Y-m-d' );   // 近7天（含今日）
		$c30  = ( clone $now )->modify( '-29 days' )->format( 'Y-m-d' );

		$today = 0; $week = 0; $month = 0;
		$uniq_to = array(); $uniq_tokens7 = array();
		$by_token = array(); $daily = array();

		foreach ( $events as $e ) {
			$ts  = self::ev_ts( $e );
			$dky = ( new DateTime( '@' . $ts ) )->setTimezone( $tz )->format( 'Y-m-d' );

			$__isClick = ( isset( $e['type'] ) && 'click' === $e['type'] );
			if ( ! $__isClick ) { $daily[ $dky ] = isset( $daily[ $dky ] ) ? $daily[ $dky ] + 1 : 1; }
			if ( ! $__isClick && $dky === $tk ) {
				$today++;
			}
			if ( ! $__isClick && $dky >= $c7 ) {
				$week++;
				$t = isset( $e['token'] ) ? $e['token'] : '';
				if ( $t ) {
					$uniq_tokens7[ $t ] = 1;
				}
				$to = isset( $e['to'] ) ? $e['to'] : '';
				if ( $to ) {
					$uniq_to[ $to ] = 1;
				}
			}
			if ( ! $__isClick && $dky >= $c30 ) {
				$month++;
			}
			$t = isset( $e['token'] ) ? $e['token'] : '';
			if ( $t ) {
				$by_token[ $t ][] = $e;
			}
		}

		$sent7 = ZET_Stats::get_sent( 7 );
		$rate  = ( $sent7 > 0 ) ? round( count( $uniq_tokens7 ) / $sent7 * 100, 1 ) : null;

		// 迷你柱状图：近 12 天每日打开
		$spark = array();
		for ( $i = 11; $i >= 0; $i-- ) {
			$dky     = ( clone $now )->modify( "-$i days" )->format( 'Y-m-d' );
			$spark[] = isset( $daily[ $dky ] ) ? $daily[ $dky ] : 0;
		}

		// 记录流（最多 300 条，含每封邮件的打开次数）
		$rows   = array();
		$tokens = array();
		$limit  = 300;
		$i      = 0;
		foreach ( $events as $e ) {
			if ( $i++ >= $limit ) {
				break;
			}
			$t      = isset( $e['token'] ) ? $e['token'] : '';
			$opens  = 0;
			if ( $t && isset( $by_token[ $t ] ) ) {
				foreach ( $by_token[ $t ] as $__e ) {
					if ( ! isset( $__e['type'] ) || 'open' === $__e['type'] ) { $opens++; }
				}
			}
			if ( $opens < 1 ) { $opens = 1; }
			$ts     = self::ev_ts( $e );
			$rows[] = array(
				't'     => wp_date( 'm-d H:i', $ts ),
				'ts'    => $ts,
				'to'    => isset( $e['to'] ) ? $e['to'] : '',
				'subj'  => isset( $e['subject'] ) ? $e['subject'] : '',
				'ip'    => isset( $e['ip'] ) ? $e['ip'] : '',
				'loc'   => isset( $e['geo'] ) ? $e['geo'] : '',
				'dev'   => isset( $e['device'] ) ? $e['device'] : '',
				'os'    => isset( $e['os'] ) ? $e['os'] : '',
				'br'    => isset( $e['browser'] ) ? $e['browser'] : '',
				'token' => $t,
				'opens' => $opens,
				'type'  => isset( $e['type'] ) ? $e['type'] : 'open',
			);
		}

		// 明细：记录流里出现过的 token → 其全部打开事件（升序）
		$seen = array();
		foreach ( $rows as $r ) {
			if ( ! $r['token'] || isset( $seen[ $r['token'] ] ) || ! isset( $by_token[ $r['token'] ] ) ) {
				continue;
			}
			$seen[ $r['token'] ] = 1;
			$list                = $by_token[ $r['token'] ];
			usort( $list, function ( $a, $b ) {
				return self::ev_ts( $a ) - self::ev_ts( $b );
			} );
			$evs = array();
			foreach ( $list as $e ) {
				$ts    = self::ev_ts( $e );
				$evs[] = array(
					't'   => wp_date( 'Y-m-d H:i:s', $ts ),
					'ip'  => isset( $e['ip'] ) ? $e['ip'] : '',
					'loc' => isset( $e['geo'] ) ? $e['geo'] : '',
					'dev' => isset( $e['device'] ) ? $e['device'] : '',
					'os'  => isset( $e['os'] ) ? $e['os'] : '',
					'br'   => isset( $e['browser'] ) ? $e['browser'] : '',
					'type' => isset( $e['type'] ) ? $e['type'] : 'open',
				);
			}
			$tokens[ $r['token'] ] = $evs;
		}

		$data = array(
			'rows'   => $rows,
			'tokens' => $tokens,
			'spark'  => $spark,
		);

		$file = ZET_Storage::file();
		?>
		<div class="wrap zet-wrap zet-dash">
			<div class="zet-dash-inner">
				<div class="zet-topbar">
					<div>
						<h1>打开记录</h1>
						<div class="zet-crumb">邮件追踪 / 打开记录 · 实时</div>
					</div>
					<div class="zet-grow"></div>
					<div class="zet-search">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
						<input id="zet-q" placeholder="搜索收件人 / 主题 / IP…">
					</div>
					<div class="zet-chips" id="zet-chips">
						<button data-days="1">今日</button>
						<button data-days="7" class="on">7 天</button>
						<button data-days="30">30 天</button>
						<button data-days="0">全部</button>
					</div>
					<a class="zet-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=zet_export' ), 'zet_export' ) ); ?>">导出 CSV</a>
					<a class="zet-btn zet-danger" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=zet_clear' ), 'zet_clear' ) ); ?>" onclick="return confirm('确定清空所有打开记录？此操作不可恢复。');">清空</a>
				</div>

				<section class="zet-stats">
					<div class="zet-card">
						<div class="zet-k">今日打开</div>
						<div class="zet-v"><?php echo esc_html( $today ); ?></div>
						<div class="zet-d">按站点时区 <?php echo esc_html( $now->format( 'Y-m-d' ) ); ?></div>
						<div class="zet-spark" data-bars="<?php echo esc_attr( implode( ',', $spark ) ); ?>"></div>
					</div>
					<div class="zet-card">
						<div class="zet-k">近 7 日打开</div>
						<div class="zet-v"><?php echo esc_html( $week ); ?></div>
						<div class="zet-d">含今日</div>
						<div class="zet-spark" data-bars="<?php echo esc_attr( implode( ',', $spark ) ); ?>"></div>
					</div>
					<div class="zet-card">
						<div class="zet-k">独立收件人</div>
						<div class="zet-v"><?php echo esc_html( count( $uniq_to ) ); ?></div>
						<div class="zet-d">近 7 日去重</div>
						<div class="zet-spark" data-bars="<?php echo esc_attr( implode( ',', $spark ) ); ?>"></div>
					</div>
					<div class="zet-card">
						<div class="zet-k">打开率</div>
						<div class="zet-v"><?php echo null === $rate ? '—' : esc_html( $rate ) . '%'; ?></div>
						<div class="zet-d">近7日有打开邮件 / 发送数（<?php echo esc_html( $sent7 ); ?>）</div>
						<div class="zet-spark" data-bars="<?php echo esc_attr( implode( ',', $spark ) ); ?>"></div>
					</div>
				</section>

				<div class="zet-sech"><h2>记录流</h2><span class="zet-n" id="zet-count"></span></div>
				<div class="zet-list" id="zet-list">
					<div class="zet-row zet-head">
						<div>时间</div><div>收件人</div><div>主题</div><div>IP · 归属地</div><div>设备 / 系统 / 浏览器</div><div style="text-align:right">打开</div>
					</div>
				</div>

				<p class="zet-note">
					存储：<strong><?php echo 'db' === $s['storage'] ? '数据库' : '文件'; ?></strong>
					<?php if ( 'db' !== $s['storage'] ) : ?>
						· <code><?php echo esc_html( $file ); ?></code>
					<?php else : ?>
						· <code><?php echo esc_html( ZET_Storage::table() ); ?></code>
					<?php endif; ?>
					<br>说明：“打开”= 至少加载过一次追踪图片，同一封邮件可能被多次加载，不等于“认真读完”。Apple Mail 预加载、Gmail 图片代理会产生偏差。
				</p>
			</div>
		</div>

		<div class="zet-mask" id="zet-mask"></div>
		<aside class="zet-drawer" id="zet-drawer">
			<div class="zet-dh">
				<button class="zet-x" id="zet-close">✕</button>
				<h3 id="zet-d-subj">—</h3>
				<div class="zet-m" id="zet-d-to">—</div>
			</div>
			<div class="zet-db">
				<div class="zet-kpis">
					<div class="zet-kpi"><div class="zet-k">打开次数</div><div class="zet-v" id="zet-d-count">—</div></div>
					<div class="zet-kpi"><div class="zet-k">首次打开</div><div class="zet-v" id="zet-d-first" style="font-size:14px">—</div></div>
					<div class="zet-kpi"><div class="zet-k">最近打开</div><div class="zet-v" id="zet-d-last" style="font-size:14px">—</div></div>
				</div>
				<div class="zet-sech"><h2>打开时间轴</h2><span class="zet-n">每次加载追踪图片都会记一条</span></div>
				<div class="zet-tl" id="zet-d-tl"></div>
			</div>
		</aside>

		<script>window.ZET_DATA = <?php echo wp_json_encode( $data ); ?>;</script>
		<?php
	}
}
