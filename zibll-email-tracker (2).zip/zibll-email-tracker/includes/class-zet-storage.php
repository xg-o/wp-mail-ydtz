<?php
/**
 * 存储层：支持「文件」与「数据库」两种方式。
 *
 * 文件模式（默认）：
 *   - 目录可自定义；留空则用 wp-content/uploads/zibll-email-tracker/
 *   - 格式：json（数组，便于读取）/ txt（每行一条）/ md（表格）/ php（带 exit 头，防直接访问）
 *   - 写入使用 flock 独占锁，避免并发丢数据
 *
 * 数据库模式：
 *   - 表名可自定义；留空则用 {prefix}zet_email_track
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Storage {

	const DEFAULT_SUBDIR = 'zibll-email-tracker';

	/* ---------- 基本信息 ---------- */

	public static function table() {
		global $wpdb;
		$s = zet_get_option();
		$t = trim( (string) $s['table_name'] );
		if ( '' === $t ) {
			$t = $wpdb->prefix . 'zet_email_track';
		}
		return preg_replace( '/[^A-Za-z0-9_]/', '', $t );
	}

	public static function dir() {
		$s   = zet_get_option();
		$dir = trim( (string) $s['file_path'] );
		if ( '' === $dir ) {
			$up  = wp_upload_dir();
			$dir = trailingslashit( $up['basedir'] ) . self::DEFAULT_SUBDIR;
		}
		return rtrim( $dir, '/\\' );
	}

	public static function format() {
		$s   = zet_get_option();
		$fmt = isset( $s['file_format'] ) ? $s['file_format'] : 'json';
		return in_array( $fmt, array( 'json', 'txt', 'md', 'php' ), true ) ? $fmt : 'json';
	}

	public static function file() {
		return trailingslashit( self::dir() ) . 'email-track.' . self::format();
	}

	/* ---------- 保存 ---------- */

	public static function save( $event ) {
		$s = zet_get_option();
		if ( ! empty( $s['fields'] ) && is_array( $s['fields'] ) ) {
			$event = self::filter( $event, $s['fields'] );
		}
		if ( isset( $s['storage'] ) && 'db' === $s['storage'] ) {
			return self::save_db( $event );
		}
		return self::save_file( $event );
	}

	/** 仅保留用户勾选的字段（token / time / 收件人 / 主题 为必要信息，始终保留） */
	private static function filter( $event, $fields ) {
		$keep = array_unique( array_merge( array( 'token', 'time', 'timestamp', 'to', 'subject', 'referer', 'type', 'url' ), $fields ) );
		$out  = array();
		foreach ( $keep as $k ) {
			if ( array_key_exists( $k, $event ) ) {
				$out[ $k ] = $event[ $k ];
			}
		}
		return $out;
	}

	private static function ensure_dir() {
		$dir = self::dir();
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		if ( is_dir( $dir ) ) {
			$ht = trailingslashit( $dir ) . '.htaccess';
			if ( ! file_exists( $ht ) ) {
				@file_put_contents( $ht, "Deny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n" );
			}
			$idx = trailingslashit( $dir ) . 'index.html';
			if ( ! file_exists( $idx ) ) {
				@file_put_contents( $idx, '' );
			}
		}
		return $dir;
	}

	private static function save_file( $event ) {
		self::ensure_dir();
		$file = self::file();
		$fmt  = self::format();

		$lock = $file . '.lock';
		$fp   = @fopen( $lock, 'c' );
		if ( $fp ) {
			@flock( $fp, LOCK_EX );
		}

		if ( 'json' === $fmt ) {
			$data = array();
			if ( file_exists( $file ) ) {
				$raw  = file_get_contents( $file );
				$data = json_decode( $raw, true );
				if ( ! is_array( $data ) ) {
					$data = array();
				}
			}
			$data[] = $event;
			@file_put_contents( $file, wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ), LOCK_EX );
		} else {
			// 首次写入表头
			if ( ! file_exists( $file ) || 0 === filesize( $file ) ) {
				if ( 'md' === $fmt ) {
					@file_put_contents( $file, "| 时间 | 收件人 | 真实IP | 地理位置 | 设备 | 系统 | 浏览器 | Token | 类型 | 链接 |\n|---|---|---|---|---|---|---|---|---|---|\n", LOCK_EX );
				} elseif ( 'php' === $fmt ) {
					@file_put_contents( $file, "<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>\n", LOCK_EX );
				}
			}
			@file_put_contents( $file, self::format_line( $event, $fmt ) . "\n", FILE_APPEND | LOCK_EX );
		}

		if ( $fp ) {
			@flock( $fp, LOCK_UN );
			@fclose( $fp );
		}
		return true;
	}

	private static function format_line( $event, $fmt ) {
		$cols = array(
			isset( $event['time'] ) ? $event['time'] : '',
			isset( $event['to'] ) ? $event['to'] : '',
			isset( $event['ip'] ) ? $event['ip'] : '',
			isset( $event['geo'] ) ? $event['geo'] : '',
			isset( $event['device'] ) ? $event['device'] : '',
			isset( $event['os'] ) ? $event['os'] : '',
			isset( $event['browser'] ) ? $event['browser'] : '',
			isset( $event['token'] ) ? $event['token'] : '',
			isset( $event['type'] ) ? $event['type'] : '',
			isset( $event['url'] ) ? $event['url'] : '',
		);
		if ( 'md' === $fmt ) {
			$cols = array_map( function ( $c ) {
				return str_replace( array( '|', "\n", "\r" ), array( '/', ' ', '' ), $c );
			}, $cols );
			return '| ' . implode( ' | ', $cols ) . ' |';
		}
		return implode( ' | ', array_map( function ( $c ) {
			return str_replace( array( "\n", "\r" ), array( ' ', '' ), $c );
		}, $cols ) );
	}

	/* ---------- 数据库 ---------- */

	public static function ensure_table() {
		global $wpdb;
		$t       = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$t} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			token VARCHAR(64) NOT NULL DEFAULT '',
			to_email VARCHAR(190) NOT NULL DEFAULT '',
			subject VARCHAR(255) NOT NULL DEFAULT '',
			ip VARCHAR(45) NOT NULL DEFAULT '',
			geo VARCHAR(190) NOT NULL DEFAULT '',
			device VARCHAR(40) NOT NULL DEFAULT '',
			os VARCHAR(60) NOT NULL DEFAULT '',
			browser VARCHAR(60) NOT NULL DEFAULT '',
			ua TEXT,
			referer VARCHAR(255) NOT NULL DEFAULT '',
			type VARCHAR(10) NOT NULL DEFAULT 'open',
			url VARCHAR(500) NOT NULL DEFAULT '',
			created DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY token (token),
			KEY created (created)
		) {$charset};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	private static function save_db( $event ) {
		global $wpdb;
		self::ensure_table();
		return $wpdb->insert(
			self::table(),
			array(
				'token'    => isset( $event['token'] ) ? $event['token'] : '',
				'to_email' => isset( $event['to'] ) ? zet_substr( $event['to'], 190 ) : '',
				'subject'  => isset( $event['subject'] ) ? zet_substr( $event['subject'], 200 ) : '',
				'ip'       => isset( $event['ip'] ) ? $event['ip'] : '',
				'geo'      => isset( $event['geo'] ) ? zet_substr( $event['geo'], 180 ) : '',
				'device'   => isset( $event['device'] ) ? $event['device'] : '',
				'os'       => isset( $event['os'] ) ? $event['os'] : '',
				'browser'  => isset( $event['browser'] ) ? $event['browser'] : '',
				'ua'       => isset( $event['ua'] ) ? $event['ua'] : '',
				'referer'  => isset( $event['referer'] ) ? zet_substr( $event['referer'], 240 ) : '',
				'type'     => isset( $event['type'] ) ? zet_substr( $event['type'], 10 ) : 'open',
				'url'      => isset( $event['url'] ) ? zet_substr( $event['url'], 500 ) : '',
				'created'  => isset( $event['time'] ) ? $event['time'] : current_time( 'mysql' ),
			)
		);
	}

	/* ---------- 读取 ---------- */

	public static function fetch( $limit = 100 ) {
		$s = zet_get_option();
		if ( isset( $s['storage'] ) && 'db' === $s['storage'] ) {
			return self::fetch_db( $limit );
		}
		return self::fetch_file( $limit );
	}

	private static function fetch_db( $limit ) {
		global $wpdb;
		$t    = self::table();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'time'    => $r['created'],
				'to'      => $r['to_email'],
				'subject' => $r['subject'],
				'ip'      => $r['ip'],
				'geo'     => $r['geo'],
				'device'  => $r['device'],
				'os'      => $r['os'],
				'browser' => $r['browser'],
				'ua'      => $r['ua'],
				'referer' => $r['referer'],
				'token'   => $r['token'],
				'type'    => isset( $r['type'] ) ? $r['type'] : 'open',
				'url'     => isset( $r['url'] ) ? $r['url'] : '',
			);
		}
		return $out;
	}

	private static function fetch_file( $limit ) {
		$file = self::file();
		if ( ! file_exists( $file ) ) {
			return array();
		}
		$fmt = self::format();

		if ( 'json' === $fmt ) {
			$data = json_decode( file_get_contents( $file ), true );
			if ( ! is_array( $data ) ) {
				return array();
			}
			$data = array_slice( $data, -$limit );
			return array_reverse( $data );
		}

		$lines = @file( $file, FILE_IGNORE_NEW_LINES );
		if ( ! is_array( $lines ) ) {
			return array();
		}
		$out = array();
		foreach ( array_reverse( $lines ) as $line ) {
			if ( count( $out ) >= $limit ) {
				break;
			}
			$parsed = self::parse_line( $line, $fmt );
			if ( $parsed ) {
				$out[] = $parsed;
			}
		}
		return $out;
	}

	private static function parse_line( $line, $fmt ) {
		$line = trim( $line );
		if ( '' === $line || false !== strpos( $line, '<?php' ) ) {
			return null;
		}
		if ( 'md' === $fmt ) {
			if ( false !== strpos( $line, '---' ) || false !== strpos( $line, '| 时间' ) ) {
				return null;
			}
			$line = trim( $line, "| \t" );
		}
		$p = array_map( 'trim', explode( '|', $line ) );
		if ( count( $p ) < 2 ) {
			return null;
		}
		return array(
			'time'    => isset( $p[0] ) ? $p[0] : '',
			'to'      => isset( $p[1] ) ? $p[1] : '',
			'ip'      => isset( $p[2] ) ? $p[2] : '',
			'geo'     => isset( $p[3] ) ? $p[3] : '',
			'device'  => isset( $p[4] ) ? $p[4] : '',
			'os'      => isset( $p[5] ) ? $p[5] : '',
			'browser' => isset( $p[6] ) ? $p[6] : '',
			'token'   => isset( $p[7] ) ? $p[7] : '',
			'type'    => isset( $p[8] ) ? $p[8] : '',
			'url'     => isset( $p[9] ) ? $p[9] : '',
		);
	}

	/* ---------- 清空 ---------- */

	public static function clear() {
		$s = zet_get_option();
		if ( isset( $s['storage'] ) && 'db' === $s['storage'] ) {
			global $wpdb;
			$t = self::table();
			$wpdb->query( "TRUNCATE TABLE {$t}" );
			return;
		}
		$file = self::file();
		if ( file_exists( $file ) ) {
			@unlink( $file );
		}
	}

	/* ---------- 清理过期 ---------- */

	public static function purge_old( $days ) {
		$days = intval( $days );
		if ( $days <= 0 ) {
			return;
		}
		$s = zet_get_option();
		if ( isset( $s['storage'] ) && 'db' === $s['storage'] ) {
			global $wpdb;
			$t = self::table();
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE created < DATE_SUB(NOW(), INTERVAL %d DAY)", $days ) );
			return;
		}
		$file = self::file();
		if ( ! file_exists( $file ) || 'json' !== self::format() ) {
			return;
		}
		$data = json_decode( file_get_contents( $file ), true );
		if ( ! is_array( $data ) ) {
			return;
		}
		$cutoff = time() - $days * DAY_IN_SECONDS;
		$data   = array_values( array_filter( $data, function ( $e ) use ( $cutoff ) {
			$ts = isset( $e['timestamp'] ) ? intval( $e['timestamp'] ) : strtotime( isset( $e['time'] ) ? $e['time'] : '' );
			return $ts >= $cutoff;
		} ) );
		@file_put_contents( $file, wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ), LOCK_EX );
	}
}
