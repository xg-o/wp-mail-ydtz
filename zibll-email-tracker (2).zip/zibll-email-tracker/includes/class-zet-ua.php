<?php
/**
 * User-Agent 解析：设备 / 系统 / 浏览器
 * 轻量自实现，不依赖第三方库，覆盖常见邮件客户端与浏览器。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_UA {

	public static function parse( $ua ) {
		$ua = (string) $ua;
		return array(
			'device'  => self::device( $ua ),
			'os'      => self::os( $ua ),
			'browser' => self::browser( $ua ),
		);
	}

	public static function device( $ua ) {
		if ( '' === $ua ) {
			return '未知';
		}
		// 邮件代理 / 预加载 / 机器人
		if ( preg_match( '/bot|crawl|spider|slurp|bingpreview|facebookexternalhit|GoogleImageProxy|YahooMailProxy|preview|monitoring|curl|wget|python|java|go-http|okhttp/i', $ua ) ) {
			return '机器人/预览';
		}
		if ( preg_match( '/iPad/i', $ua ) ) {
			return '平板(iPad)';
		}
		if ( preg_match( '/Tablet|PlayBook|Kindle|Silk|Nexus 7|Nexus 10/i', $ua ) ) {
			return '平板';
		}
		if ( preg_match( '/Mobile|iPhone|iPod|Windows Phone|BlackBerry|Opera Mini|IEMobile/i', $ua ) ) {
			return '手机';
		}
		if ( preg_match( '/Android/i', $ua ) ) {
			return '平板';
		}
		return '电脑';
	}

	public static function os( $ua ) {
		if ( '' === $ua ) {
			return '未知';
		}
		$map = array(
			'/Windows NT 10\.0/'   => 'Windows 10/11',
			'/Windows NT 6\.3/'    => 'Windows 8.1',
			'/Windows NT 6\.2/'    => 'Windows 8',
			'/Windows NT 6\.1/'    => 'Windows 7',
			'/Windows NT 6\.0/'    => 'Windows Vista',
			'/Windows NT/'         => 'Windows',
			'/iPhone|iPad|iPod/'   => 'iOS',
			'/Android/'            => 'Android',
			'/Windows Phone/'      => 'Windows Phone',
			'/Mac OS X|Macintosh/' => 'macOS',
			'/CrOS/'               => 'Chrome OS',
			'/Linux/'              => 'Linux',
		);
		foreach ( $map as $re => $name ) {
			if ( preg_match( $re, $ua ) ) {
				return $name;
			}
		}
		return '其他';
	}

	public static function browser( $ua ) {
		if ( '' === $ua ) {
			return '未知';
		}
		if ( false !== stripos( $ua, 'MicroMessenger' ) ) {
			return '微信';
		}
		if ( false !== stripos( $ua, 'QQBrowser' ) || preg_match( '/QQ\//', $ua ) ) {
			return 'QQ浏览器';
		}
		if ( false !== stripos( $ua, 'UCBrowser' ) || false !== stripos( $ua, 'UCWEB' ) ) {
			return 'UC浏览器';
		}
		if ( false !== stripos( $ua, 'Edg' ) ) {
			return 'Edge';
		}
		if ( false !== stripos( $ua, 'OPR' ) || false !== stripos( $ua, 'Opera' ) ) {
			return 'Opera';
		}
		if ( false !== stripos( $ua, 'Firefox' ) || false !== stripos( $ua, 'FxiOS' ) ) {
			return 'Firefox';
		}
		if ( false !== stripos( $ua, 'CriOS' ) || false !== stripos( $ua, 'Chrome' ) ) {
			return 'Chrome';
		}
		if ( false !== stripos( $ua, 'Safari' ) ) {
			return 'Safari';
		}
		if ( false !== stripos( $ua, 'MSIE' ) || false !== stripos( $ua, 'Trident' ) ) {
			return 'IE';
		}
		return '其他';
	}
}
