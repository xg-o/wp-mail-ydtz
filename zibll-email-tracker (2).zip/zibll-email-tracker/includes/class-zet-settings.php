<?php
/**
 * 后台：设置页 + 打开记录页
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Settings {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_zet_clear', array( $this, 'handle_clear' ) );
		add_action( 'admin_post_zet_export', array( $this, 'handle_export' ) );
	}

	public function menu() {
		add_menu_page( '邮件追踪', '邮件追踪', 'manage_options', 'zet-records', array( $this, 'records_page' ), 'dashicons-email-alt', 58 );
		add_submenu_page( 'zet-records', '打开记录', '打开记录', 'manage_options', 'zet-records', array( $this, 'records_page' ) );
		add_submenu_page( 'zet-records', '设置', '设置', 'manage_options', 'zet-settings', array( $this, 'settings_page' ) );
	}

	public function assets( $hook ) {
		$hook = (string) $hook;
		if ( false === strpos( $hook, 'zet-' ) ) {
			return;
		}
		wp_enqueue_style( 'zet-admin', ZET_URL . 'assets/admin.css', array(), ZET_VERSION );
		if ( false !== strpos( $hook, 'zet-records' ) ) {
			wp_enqueue_style( 'zet-dashboard', ZET_URL . 'assets/dashboard.css', array(), ZET_VERSION );
			wp_enqueue_script( 'zet-dashboard', ZET_URL . 'assets/dashboard.js', array(), ZET_VERSION, true );
		}
	}

	/* ---------- 注册设置 ---------- */

	public function register() {
		register_setting(
			'zet_group',
			ZET_OPTION,
			array( 'sanitize_callback' => array( $this, 'sanitize' ), 'default' => zet_defaults() )
		);
	}

	public function sanitize( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$out = array();

		$out['enabled']     = empty( $in['enabled'] ) ? 0 : 1;
		$out['auto_inject'] = empty( $in['auto_inject'] ) ? 0 : 1;

		$out['storage'] = ( isset( $in['storage'] ) && in_array( $in['storage'], array( 'file', 'db' ), true ) ) ? $in['storage'] : 'file';

		$out['file_path'] = isset( $in['file_path'] ) ? sanitize_text_field( $in['file_path'] ) : '';

		$out['file_format'] = ( isset( $in['file_format'] ) && in_array( $in['file_format'], array( 'json', 'txt', 'md', 'php' ), true ) ) ? $in['file_format'] : 'json';

		$out['table_name'] = isset( $in['table_name'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', $in['table_name'] ) : '';

		$allowed        = array_keys( zet_field_labels() );
		$fields         = ( isset( $in['fields'] ) && is_array( $in['fields'] ) ) ? array_values( array_intersect( $allowed, $in['fields'] ) ) : array();
		$out['fields']  = $fields ? $fields : array( 'ip', 'geo', 'device', 'os', 'browser' );

		// IP 信息获取方式
		$out['geo_mode'] = ( isset( $in['geo_mode'] ) && in_array( $in['geo_mode'], array( 'off', 'builtin', 'api' ), true ) ) ? $in['geo_mode'] : 'builtin';

		$presets          = array_keys( ZET_Geo::providers() );
		$out['geo_preset'] = ( isset( $in['geo_preset'] ) && in_array( $in['geo_preset'], $presets, true ) ) ? $in['geo_preset'] : 'ipapi';

		$out['geo_url'] = isset( $in['geo_url'] ) ? sanitize_text_field( $in['geo_url'] ) : '';
		$out['geo_key'] = isset( $in['geo_key'] ) ? sanitize_text_field( $in['geo_key'] ) : '';

		$cfpath = array();
		foreach ( array( 'country', 'region', 'city', 'isp' ) as $f ) {
			$cfpath[ $f ] = ( isset( $in['geo_c_fields'][ $f ] ) && '' !== $in['geo_c_fields'][ $f ] ) ? sanitize_text_field( $in['geo_c_fields'][ $f ] ) : $f;
		}
		$out['geo_c_fields'] = $cfpath;

		$out['keep_days'] = max( 0, intval( isset( $in['keep_days'] ) ? $in['keep_days'] : 0 ) );
		$out['url_mode']   = ( isset( $in['url_mode'] ) && in_array( $in['url_mode'], array( 'rewrite', 'query' ), true ) ) ? $in['url_mode'] : 'rewrite';

		// ── v2.0：功能开关 ──
		$features = array( 'click_track' => 0, 'notify' => 0, 'ratelimit' => 0, 'compliance' => 0, 'whitelist' => 0 );
		foreach ( $features as $fk => $dv ) {
			$features[ $fk ] = ( ! empty( $in['features'][ $fk ] ) ) ? 1 : 0;
		}
		$out['features'] = $features;

		// ── v2.0：通知 ──
		$out['notify_events'] = ( isset( $in['notify_events'] ) && is_array( $in['notify_events'] ) ) ? array_values( array_intersect( array( 'open', 'click', 'ratelimit' ), $in['notify_events'] ) ) : array();
		$chans = array();
		foreach ( array_keys( ZET_Notify::channels() ) as $c ) {
			$chans[ $c ] = ( ! empty( $in['notify_channels'][ $c ] ) ) ? 1 : 0;
		}
		$out['notify_channels'] = $chans;
		foreach ( array( 'notify_email', 'notify_webhook_url', 'notify_wecom_url', 'notify_serverchan_key', 'notify_bark_url', 'notify_tg_token', 'notify_tg_chat', 'notify_qq_url' ) as $nk ) {
			$out[ $nk ] = isset( $in[ $nk ] ) ? sanitize_text_field( $in[ $nk ] ) : '';
		}
		$out['notify_min_interval'] = max( 0, intval( isset( $in['notify_min_interval'] ) ? $in['notify_min_interval'] : 0 ) );

		// ── v2.0：点击追踪 ──
		$out['click_exclude'] = isset( $in['click_exclude'] ) ? sanitize_text_field( $in['click_exclude'] ) : '';

		// ── v2.0：安全 / 合规 ──
		$out['ratelimit_per_ip'] = max( 0, intval( isset( $in['ratelimit_per_ip'] ) ? $in['ratelimit_per_ip'] : 20 ) );
		$out['ratelimit_window'] = max( 0, intval( isset( $in['ratelimit_window'] ) ? $in['ratelimit_window'] : 3600 ) );
		$out['ratelimit_action'] = ( isset( $in['ratelimit_action'] ) && in_array( $in['ratelimit_action'], array( 'log', 'block' ), true ) ) ? $in['ratelimit_action'] : 'log';
		$out['log_file']         = isset( $in['log_file'] ) ? sanitize_text_field( $in['log_file'] ) : '';
		$out['bl_enabled'] = empty( $in['bl_enabled'] ) ? 0 : 1;
		$out['bl_roles']   = ( isset( $in['bl_roles'] ) && is_array( $in['bl_roles'] ) ) ? array_map( 'sanitize_text_field', $in['bl_roles'] ) : array();
		$out['bl_emails']  = isset( $in['bl_emails'] ) ? sanitize_textarea_field( $in['bl_emails'] ) : '';
		$out['wl_enabled'] = empty( $in['wl_enabled'] ) ? 0 : 1;
		$out['wl_roles']   = ( isset( $in['wl_roles'] ) && is_array( $in['wl_roles'] ) ) ? array_map( 'sanitize_text_field', $in['wl_roles'] ) : array();
		$out['wl_emails']  = isset( $in['wl_emails'] ) ? sanitize_textarea_field( $in['wl_emails'] ) : '';

		// 合规模式（多选）
		$out['comp_ip_anon']  = empty( $in['comp_ip_anon'] ) ? 0 : 1;
		$out['comp_drop_ua']  = empty( $in['comp_drop_ua'] ) ? 0 : 1;
		$out['comp_drop_geo'] = empty( $in['comp_drop_geo'] ) ? 0 : 1;

		// 告知文字
		$out['notice_enable'] = empty( $in['notice_enable'] ) ? 0 : 1;
		$out['notice_text']   = isset( $in['notice_text'] ) ? sanitize_textarea_field( $in['notice_text'] ) : '';

		// 切换存储方式时确保数据库表存在
		if ( 'db' === $out['storage'] ) {
			ZET_Storage::ensure_table();
		}

		return $out;
	}

	/* ---------- 设置页 ---------- */

	public function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s        = zet_get_option();
		$labels   = zet_field_labels();
		$settings = ZET_OPTION;
		?>
		<div class="wrap zet-wrap">
			<h1>邮件追踪设置</h1>
			<p class="zet-desc">在邮件正文插入 1×1 透明追踪像素，记录收件人打开邮件的时间 / 真实 IP / 地理位置 / 设备 / 系统 / 浏览器。</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'zet_group' ); ?>

				<h2 class="zet-h2">基础</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">功能开关</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[enabled]" value="1" <?php checked( 1, $s['enabled'] ); ?>> 开启邮件打开追踪</label>
							<p class="description">关闭后不再记录任何打开事件（已存在的记录保留）。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">自动注入</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[auto_inject]" value="1" <?php checked( 1, $s['auto_inject'] ); ?>> 自动为 wp_mail 发送的 HTML 邮件注入追踪像素</label>
							<p class="description">子比主题的邮件通知、WordPress 自带邮件均走 wp_mail，开启后自动生效。也可用短代码/函数手动注入。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">追踪地址形式</th>
						<td>
							<select name="<?php echo esc_attr( $settings ); ?>[url_mode]">
								<option value="rewrite" <?php selected( 'rewrite', $s['url_mode'] ); ?>>美化链接 /track/&lt;token&gt;.gif（推荐）</option>
								<option value="query" <?php selected( 'query', $s['url_mode'] ); ?>>参数链接 /?zet_t=&lt;token&gt;（兼容性更好）</option>
							</select>
							<p class="description">若用美化链接，请确保 WordPress「固定链接」不是「朴素」模式，并在保存设置后到「设置→固定链接」点一次保存以刷新规则。</p>
						</td>
					</tr>
				</table>

				<h2 class="zet-h2">存储方式</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">存储位置</th>
						<td>
							<label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[storage]" value="file" <?php checked( 'file', $s['storage'] ); ?>> 文件（默认）</label>
							<label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[storage]" value="db" <?php checked( 'db', $s['storage'] ); ?>> 数据库</label>
						</td>
					</tr>
					<tr>
						<th scope="row">文件目录</th>
						<td>
							<input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[file_path]" value="<?php echo esc_attr( $s['file_path'] ); ?>" placeholder="留空 = wp-content/uploads/zibll-email-tracker">
							<p class="description">服务器绝对路径。留空则使用上传目录下的 <code>zibll-email-tracker</code>。目录会自动创建并写入 <code>.htaccess</code> 禁止直接访问。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">文件格式</th>
						<td>
							<select name="<?php echo esc_attr( $settings ); ?>[file_format]">
								<option value="json" <?php selected( 'json', $s['file_format'] ); ?>>JSON（推荐，结构化、便于读取）</option>
								<option value="txt" <?php selected( 'txt', $s['file_format'] ); ?>>TXT（每行一条，记事本可看）</option>
								<option value="md" <?php selected( 'md', $s['file_format'] ); ?>>Markdown（表格，便于分享）</option>
								<option value="php" <?php selected( 'php', $s['file_format'] ); ?>>PHP（带 exit 头，防直接访问）</option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">数据库表名</th>
						<td>
							<input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[table_name]" value="<?php echo esc_attr( $s['table_name'] ); ?>" placeholder="留空 = <?php global $wpdb; echo esc_attr( $wpdb->prefix ); ?>zet_email_track">
							<p class="description">仅含字母、数字、下划线。留空则自动使用带 WordPress 前缀的表名。</p>
						</td>
					</tr>
				</table>

				<h2 class="zet-h2">记录内容</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">勾选要记录的信息</th>
						<td>
							<?php foreach ( $labels as $k => $label ) : ?>
								<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[fields][]" value="<?php echo esc_attr( $k ); ?>" <?php checked( in_array( $k, (array) $s['fields'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
							<?php endforeach; ?>
							<p class="description">时间、收件人、主题、Token 为基础信息，始终记录。UA 为浏览器原始标识串（便于排查，占空间较大）。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">IP 信息获取方式</th>
						<td>
							<label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[geo_mode]" value="off" <?php checked( 'off', $s['geo_mode'] ); ?>> 不获取</label>
							<label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[geo_mode]" value="builtin" <?php checked( 'builtin', $s['geo_mode'] ); ?>> 插件内置</label>
							<label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[geo_mode]" value="api" <?php checked( 'api', $s['geo_mode'] ); ?>> API 接口</label>
							<p class="description">「内置」= 插件自带、开箱即用（默认走 ip-api.com 免费接口，无需配置）；「API」= 使用下方接口，可选预设服务商或自定义。</p>
						</td>
					</tr>

					<tr class="zet-geo-row zet-geo-api">
						<th scope="row">接口预设</th>
						<td>
							<select name="<?php echo esc_attr( $settings ); ?>[geo_preset]" id="zet-geo-preset">
								<?php foreach ( ZET_Geo::providers() as $key => $p ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, $s['geo_preset'] ); ?>><?php echo esc_html( $p['label'] ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description">预设已内置对应地址与字段解析，选预设即可用；如需对接自建/其它接口，选「自定义接口」。</p>
						</td>
					</tr>

					<tr class="zet-geo-row zet-geo-api zet-geo-custom">
						<th scope="row">自定义接口地址</th>
						<td>
							<input type="text" class="large-text code" name="<?php echo esc_attr( $settings ); ?>[geo_url]" value="<?php echo esc_attr( $s['geo_url'] ); ?>" placeholder="https://api.example.com/ip?q={ip}&key={key}">
							<p class="description">用 <code>{ip}</code> 占位 IP、<code>{key}</code> 占位下方 Key。仅「自定义接口」时生效。</p>
						</td>
					</tr>

					<tr class="zet-geo-row zet-geo-api zet-geo-custom">
						<th scope="row">返回字段路径</th>
						<td>
							国家 <input type="text" class="small-text code" name="<?php echo esc_attr( $settings ); ?>[geo_c_fields][country]" value="<?php echo esc_attr( $s['geo_c_fields']['country'] ); ?>" placeholder="country">
							省/区 <input type="text" class="small-text code" name="<?php echo esc_attr( $settings ); ?>[geo_c_fields][region]" value="<?php echo esc_attr( $s['geo_c_fields']['region'] ); ?>" placeholder="region">
							城市 <input type="text" class="small-text code" name="<?php echo esc_attr( $settings ); ?>[geo_c_fields][city]" value="<?php echo esc_attr( $s['geo_c_fields']['city'] ); ?>" placeholder="city">
							运营商 <input type="text" class="small-text code" name="<?php echo esc_attr( $settings ); ?>[geo_c_fields][isp]" value="<?php echo esc_attr( $s['geo_c_fields']['isp'] ); ?>" placeholder="isp">
							<p class="description">自定义接口返回 JSON 中对应字段的路径，用点号表示层级，如 <code>data.city</code>；留空表示不取该项。</p>
						</td>
					</tr>

					<tr class="zet-geo-row zet-geo-api">
						<th scope="row">接口 Key / Token</th>
						<td>
							<input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[geo_key]" value="<?php echo esc_attr( $s['geo_key'] ); ?>" placeholder="部分服务商必填">
							<p class="description">ipinfo / 淘宝 / 高德等需要；ip-api.com 免费版不需要。</p>
						</td>
					</tr>
					<tr>
						<th scope="row">记录保留天数</th>
						<td>
							<input type="number" min="0" step="1" name="<?php echo esc_attr( $settings ); ?>[keep_days]" value="<?php echo esc_attr( $s['keep_days'] ); ?>" class="small-text"> 天
							<p class="description">0 = 永久保留。每天自动清理一次过期记录。</p>
						</td>
					</tr>
				</table>

									<h2 class="zet-h2">功能开关（v2.0）</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row">链接点击追踪</th><td><label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[features][click_track]" value="1" <?php checked( 1, $s['features']['click_track'] ); ?>> 启用</label><p class="description">把正文外链改写为 <code>/go/&lt;id&gt;</code>，记录点击（IP/归属地/设备/时间/原链接）。</p></td></tr>
						<tr><th scope="row">实时通知</th><td><label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[features][notify]" value="1" <?php checked( 1, $s['features']['notify'] ); ?>> 启用</label><p class="description">打开 / 点击 / 疑似刷流量时推送到下方渠道。</p></td></tr>
						<tr><th scope="row">防刷限流</th><td><label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[features][ratelimit]" value="1" <?php checked( 1, $s['features']['ratelimit'] ); ?>> 启用</label><p class="description">同一 IP 短时间内频繁触发 → 判定疑似刷流量。</p></td></tr>
						<tr><th scope="row">合规模式</th><td><label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[features][compliance]" value="1" <?php checked( 1, $s['features']['compliance'] ); ?>> 启用</label><p class="description">IP 匿名化（末段归零）、不记录原始 UA。</p></td></tr>
						<tr><th scope="row">黑白名单</th><td><label><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[features][whitelist]" value="1" <?php checked( 1, $s['features']['whitelist'] ); ?>> 启用</label><p class="description">按收件人邮箱/域名与其 WP 用户角色决定是否跟踪（见下方）。</p></td></tr>
					</table>

					<h2 class="zet-h2">通知中心</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row">通知事件</th><td>
							<?php foreach ( ZET_Notify::events() as $ek => $el ) : ?>
								<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[notify_events][]" value="<?php echo esc_attr( $ek ); ?>" <?php checked( in_array( $ek, (array) $s['notify_events'], true ) ); ?>> <?php echo esc_html( $el ); ?></label>
							<?php endforeach; ?>
						</td></tr>
						<tr><th scope="row">通知渠道</th><td>
							<?php foreach ( ZET_Notify::channels() as $ck => $cl ) : ?>
								<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[notify_channels][<?php echo esc_attr( $ck ); ?>]" value="1" <?php checked( 1, (int) $s['notify_channels'][ $ck ] ); ?>> <?php echo esc_html( $cl ); ?></label>
							<?php endforeach; ?>
						</td></tr>
						<tr><th scope="row">邮件收件人</th><td><input type="text" class="regular-text" name="<?php echo esc_attr( $settings ); ?>[notify_email]" value="<?php echo esc_attr( $s['notify_email'] ); ?>" placeholder="留空=站点管理员邮箱"></td></tr>
						<tr><th scope="row">自定义 Webhook</th><td><input type="text" class="large-text code" name="<?php echo esc_attr( $settings ); ?>[notify_webhook_url]" value="<?php echo esc_attr( $s['notify_webhook_url'] ); ?>" placeholder="https://... （POST JSON：event/title/text/data）"><p class="description">可用于对接<b>短信</b>、钉钉、飞书等任意 API。</p></td></tr>
						<tr><th scope="row">企业微信机器人</th><td><input type="text" class="large-text code" name="<?php echo esc_attr( $settings ); ?>[notify_wecom_url]" value="<?php echo esc_attr( $s['notify_wecom_url'] ); ?>" placeholder="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=..."></td></tr>
						<tr><th scope="row">Server酱 Key</th><td><input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[notify_serverchan_key]" value="<?php echo esc_attr( $s['notify_serverchan_key'] ); ?>" placeholder="SCT..."></td></tr>
						<tr><th scope="row">Bark 地址</th><td><input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[notify_bark_url]" value="<?php echo esc_attr( $s['notify_bark_url'] ); ?>" placeholder="https://api.day.app/你的Key"></td></tr>
						<tr><th scope="row">Telegram</th><td>Token <input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[notify_tg_token]" value="<?php echo esc_attr( $s['notify_tg_token'] ); ?>"> &nbsp; chat_id <input type="text" class="small-text code" name="<?php echo esc_attr( $settings ); ?>[notify_tg_chat]" value="<?php echo esc_attr( $s['notify_tg_chat'] ); ?>"></td></tr>
						<tr><th scope="row">QQ 机器人 Webhook</th><td><input type="text" class="large-text code" name="<?php echo esc_attr( $settings ); ?>[notify_qq_url]" value="<?php echo esc_attr( $s['notify_qq_url'] ); ?>" placeholder="群机器人 Webhook URL"></td></tr>
						<tr><th scope="row">通知节流</th><td><input type="number" min="0" class="small-text" name="<?php echo esc_attr( $settings ); ?>[notify_min_interval]" value="<?php echo esc_attr( $s['notify_min_interval'] ); ?>"> 秒<p class="description">同一封邮件同一事件在此时间内只通知一次。</p></td></tr>
					</table>

					<h2 class="zet-h2">链接点击追踪</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row">不追踪的链接</th><td><input type="text" class="large-text code" name="<?php echo esc_attr( $settings ); ?>[click_exclude]" value="<?php echo esc_attr( $s['click_exclude'] ); ?>" placeholder="unsubscribe, /account"><p class="description">逗号分隔；链接中含该串则不改写（退订链接默认跳过）。</p></td></tr>
					</table>

					<h2 class="zet-h2">安全 / 合规</h2>
					<table class="form-table" role="presentation">
						<tr><th scope="row">限流阈值</th><td>同 IP <input type="number" min="0" class="small-text" name="<?php echo esc_attr( $settings ); ?>[ratelimit_per_ip]" value="<?php echo esc_attr( $s['ratelimit_per_ip'] ); ?>"> 次 / <input type="number" min="0" class="small-text" name="<?php echo esc_attr( $settings ); ?>[ratelimit_window]" value="<?php echo esc_attr( $s['ratelimit_window'] ); ?>"> 秒</td></tr>
						<tr><th scope="row">超出处理</th><td><label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[ratelimit_action]" value="log" <?php checked( 'log', $s['ratelimit_action'] ); ?>> 仅记录</label><label class="zet-radio"><input type="radio" name="<?php echo esc_attr( $settings ); ?>[ratelimit_action]" value="block" <?php checked( 'block', $s['ratelimit_action'] ); ?>> 不入库</label></td></tr>
						<tr><th scope="row">日志文件</th><td><input type="text" class="regular-text code" name="<?php echo esc_attr( $settings ); ?>[log_file]" value="<?php echo esc_attr( $s['log_file'] ); ?>" placeholder="留空 = uploads/zibll-email-tracker/guard.log"></td></tr>
												<tr><th scope="row">黑名单</th><td>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[bl_enabled]" value="1" <?php checked( 1, $s['bl_enabled'] ); ?>> 启用</label>
							<p class="description">命中者一律<strong>不跟踪</strong>（优先级最高）。</p>
							<div>按角色：<?php foreach ( wp_roles()->get_names() as $rk => $rn ) : ?><label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[bl_roles][]" value="<?php echo esc_attr( $rk ); ?>" <?php checked( in_array( $rk, (array) $s['bl_roles'], true ) ); ?>> <?php echo esc_html( translate_user_role( $rn ) ); ?></label><?php endforeach; ?></div>
							<textarea class="large-text code" rows="3" name="<?php echo esc_attr( $settings ); ?>[bl_emails]" placeholder="user@example.com&#10;@qq.com"><?php echo esc_textarea( $s['bl_emails'] ); ?></textarea>
							<p class="description">每行一个邮箱或 <code>@域名</code>。</p>
						</td></tr>
						<tr><th scope="row">白名单</th><td>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[wl_enabled]" value="1" <?php checked( 1, $s['wl_enabled'] ); ?>> 启用</label>
							<p class="description">启用且名单非空时<strong>仅跟踪命中者</strong>；与黑名单可同时存在（黑名单优先）。</p>
							<div>按角色：<?php foreach ( wp_roles()->get_names() as $rk => $rn ) : ?><label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[wl_roles][]" value="<?php echo esc_attr( $rk ); ?>" <?php checked( in_array( $rk, (array) $s['wl_roles'], true ) ); ?>> <?php echo esc_html( translate_user_role( $rn ) ); ?></label><?php endforeach; ?></div>
							<textarea class="large-text code" rows="3" name="<?php echo esc_attr( $settings ); ?>[wl_emails]" placeholder="user@example.com&#10;@qq.com"><?php echo esc_textarea( $s['wl_emails'] ); ?></textarea>
							<p class="description">每行一个邮箱或 <code>@域名</code>。</p>
						</td></tr>
						<tr><th scope="row">合规模式选项</th><td>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[comp_ip_anon]" value="1" <?php checked( 1, $s['comp_ip_anon'] ); ?>> IP 匿名化（末段归零）</label>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[comp_drop_ua]" value="1" <?php checked( 1, $s['comp_drop_ua'] ); ?>> 不记录原始 UA</label>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[comp_drop_geo]" value="1" <?php checked( 1, $s['comp_drop_geo'] ); ?>> 不记录地理位置</label>
							<p class="description">可多选；需上方「功能开关 → 合规模式」总开关开启时生效。</p>
						</td></tr>
						<tr><th scope="row">合规告知文字</th><td>
							<label class="zet-radio"><input type="checkbox" name="<?php echo esc_attr( $settings ); ?>[notice_enable]" value="1" <?php checked( 1, $s['notice_enable'] ); ?>> 在邮件底部附加告知</label>
							<textarea class="large-text code" rows="3" name="<?php echo esc_attr( $settings ); ?>[notice_text]"><?php echo esc_textarea( $s['notice_text'] ); ?></textarea>
							<p class="description">向收件人告知邮件含追踪，满足合规要求。</p>
						</td></tr>
					</table>

<?php submit_button( '保存设置' ); ?>
			</form>

			<h2 class="zet-h2">使用方式</h2>
			<div class="zet-box">
				<p><strong>1. 自动注入（推荐）</strong>：开启「自动注入」后，任何走 <code>wp_mail()</code> 的 HTML 邮件（含子比主题邮件通知）都会自动带上追踪像素，无需改代码。</p>
				<p><strong>2. 手动注入</strong>：在自定义邮件正文里插入函数返回的像素标签：</p>
				<pre>&lt;?php echo ZET_Tracker::instance()->pixel_html( ZET_Tracker::instance()->create_token( 'to@example.com', '邮件主题' ) ); ?&gt;</pre>
				<p><strong>3. 配合子比主题</strong>：子比主题的「邮件通知 / SMTP」功能发送的邮件走 wp_mail，开启自动注入即可。</p>
			</div>

			<h2 class="zet-h2">原理 / 注意（务必阅读）</h2>
			<div class="zet-box zet-warn">
				<p><strong>原理</strong>：在 HTML 正文里插入一张 1×1 透明图片（追踪像素），图片 URL 指向本站 <code>/track/&lt;token&gt;.gif</code>。收件人用邮件客户端打开邮件时，客户端会去加载这张图 —— 于是请求回到网站，我们就能在那一刻拿到对方的真实 IP、地理位置、设备、系统、浏览器和时间。</p>
				<p><strong>请求链路</strong>：邮件客户端 → <code>GET /track/&lt;token&gt;.gif</code> → 记录打开事件 → 写入存储（文件/数据库）→ 后台「打开记录」展示。</p>
				<hr>
				<p><strong>注意：</strong></p>
				<ol>
					<li>是否加载图片取决于客户端：多数客户端需用户「允许显示远程图片」才加载；Gmail 会通过 Google 图片代理加载，隐藏收件人真实 IP。</li>
					<li>同一封邮件可能被多次加载（重复打开、预览、转发），所以「打开」=「至少加载过一次图片」，<strong>不等于「认真读完」</strong>。</li>
					<li>Apple Mail「隐私保护」、部分客户端会预加载所有图片，可能造成误报（表现为刚发出就「被打开」）。</li>
					<li>纯文本邮件无法追踪，必须是 HTML 邮件。</li>
					<li>IP 归属地依赖第三方接口，准确性有限；使用 CDN/代理时 IP 可能为节点地址。</li>
					<li>请遵守《个人信息保护法》/GDPR：记录他人 IP、位置等信息需取得合法授权，并告知对方。请勿用于非法用途。</li>
				</ol>
			</div>
		</div>
		<script>
		(function(){
			var rows = document.querySelectorAll('.zet-geo-api');
			function mode(){ var e=document.querySelector('input[name$="[geo_mode]"]:checked'); return e?e.value:'builtin'; }
			function preset(){ var e=document.getElementById('zet-geo-preset'); return e?e.value:'ipapi'; }
			function refresh(){
				var m=mode(), p=preset();
				document.querySelectorAll('.zet-geo-row').forEach(function(r){ r.style.display='none'; });
				if(m==='api'){
					rows.forEach(function(r){
						if(r.classList.contains('zet-geo-custom') && p!=='custom') return;
						r.style.display='';
					});
				}
			}
			document.querySelectorAll('input[name$="[geo_mode]"]').forEach(function(i){ i.addEventListener('change',refresh); });
			var sel=document.getElementById('zet-geo-preset'); if(sel) sel.addEventListener('change',refresh);
			refresh();
		})();
		</script>
		<?php
	}

	/* ---------- 记录页 ---------- */

	public function records_page() {
		ZET_Dashboard::render();
	}

	/* ---------- 动作 ---------- */

	public function handle_clear() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '无权限' );
		}
		check_admin_referer( 'zet_clear' );
		ZET_Storage::clear();
		wp_safe_redirect( admin_url( 'admin.php?page=zet-records&cleared=1' ) );
		exit;
	}

	public function handle_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( '无权限' );
		}
		check_admin_referer( 'zet_export' );

		$rows = ZET_Storage::fetch( 5000 );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=email-track-' . gmdate( 'Ymd-His' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // BOM，Excel 中文不乱码
		fputcsv( $out, array( '时间', '收件人', '主题', '真实IP', '地理位置', '设备', '系统', '浏览器', 'UA', 'Token' ) );
		foreach ( $rows as $r ) {
			fputcsv( $out, array(
				isset( $r['time'] ) ? $r['time'] : '',
				isset( $r['to'] ) ? $r['to'] : '',
				isset( $r['subject'] ) ? $r['subject'] : '',
				isset( $r['ip'] ) ? $r['ip'] : '',
				isset( $r['geo'] ) ? $r['geo'] : '',
				isset( $r['device'] ) ? $r['device'] : '',
				isset( $r['os'] ) ? $r['os'] : '',
				isset( $r['browser'] ) ? $r['browser'] : '',
				isset( $r['ua'] ) ? $r['ua'] : '',
				isset( $r['token'] ) ? $r['token'] : '',
			) );
		}
		fclose( $out );
		exit;
	}
}
