<?php
/**
 * 链接点击追踪：把邮件正文里的 <a href> 改写为本站 /go/<id> 跳转链接。
 * 收件人点击 → 记录点击（IP/归属地/设备/时间/原始链接）→ 302 跳转到原地址。
 * 点击事件与邮件「打开」共用同一 token，便于按邮件归并查看。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Click {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_rewrite' ) );
		add_action( 'init', array( $this, 'maybe_handle' ), 2 );
		add_filter( 'query_vars', array( $this, 'query_vars' ) );
	}

	public function query_vars( $v ) {
		$v[] = 'zet_go';
		return $v;
	}

	public function register_rewrite() {
		add_rewrite_rule( '^go/([A-Za-z0-9_\-]{6,64})$', 'index.php?zet_go=$matches[1]', 'top' );
	}

	public function go_url( $id ) {
		$s = zet_get_option();
		if ( isset( $s['url_mode'] ) && 'query' === $s['url_mode'] ) {
			return add_query_arg( 'zet_go', $id, home_url( '/' ) );
		}
		return home_url( '/go/' . $id );
	}

	/** 改写正文中的外链（由 tracker 在注入像素时调用） */
	public function rewrite( $message, $to, $subject, $token ) {
		$s = zet_get_option();
		if ( empty( $s['features']['click_track'] ) || '' === $message ) {
			return $message;
		}
		if ( false === stripos( $message, '<a' ) ) {
			return $message;
		}

		$exclude = preg_split( '/[\s,]+/', (string) ( isset( $s['click_exclude'] ) ? $s['click_exclude'] : '' ) );
		$exclude = array_filter( array_map( 'trim', (array) $exclude ) );

		return preg_replace_callback(
			'#<a\b([^>]*?)href=("|\')(https?://[^"\']+)\2#i',
			function ( $m ) use ( $to, $subject, $token, $exclude ) {
				$url = $m[3];
				foreach ( $exclude as $ex ) {
					if ( '' !== $ex && false !== stripos( $url, $ex ) ) {
						return $m[0];
					}
				}
				if ( false !== stripos( $url, 'unsubscribe' ) ) {
					return $m[0];
				}
				$id = self::register( $url, $to, $subject, $token );
				if ( ! $id ) {
					return $m[0];
				}
				return str_replace( $url, $this->go_url( $id ), $m[0] );
			},
			$message
		);
	}

	public static function register( $url, $to, $subject, $token ) {
		$id = wp_generate_password( 16, false, false );
		set_transient(
			'zet_clk_' . $id,
			array(
				'url'     => $url,
				'to'      => $to,
				'subject' => $subject,
				'token'   => $token,
				'created' => current_time( 'mysql' ),
			),
			60 * DAY_IN_SECONDS
		);
		return $id;
	}

	public function maybe_handle() {
		if ( is_admin() ) {
			return;
		}
		$id = '';
		if ( isset( $_GET['zet_go'] ) ) { // phpcs:ignore
			$id = sanitize_text_field( wp_unslash( $_GET['zet_go'] ) ); // phpcs:ignore
		} else {
			$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
			if ( preg_match( '#/go/([A-Za-z0-9_\-]{6,64})#', $uri, $m ) ) {
				$id = $m[1];
			}
		}
		if ( '' === $id || ! preg_match( '/^[A-Za-z0-9_\-]{6,64}$/', $id ) ) {
			return;
		}

		$s = zet_get_option();
		$rec = get_transient( 'zet_clk_' . $id );
		$url = ( is_array( $rec ) && ! empty( $rec['url'] ) ) ? $rec['url'] : home_url( '/' );

		if ( ! empty( $s['features']['click_track'] ) && is_array( $rec ) ) {
			$this->record( $rec );
		}

		if ( ! headers_sent() ) {
			wp_redirect( $url, 302 ); // phpcs:ignore
		}
		exit;
	}

	private function record( $rec ) {
		$s   = zet_get_option();
		$ip  = ZET_Tracker::real_ip();
		$ua  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 500 ) : ''; // phpcs:ignore
		$par = ZET_UA::parse( $ua );
		$to  = isset( $rec['to'] ) ? $rec['to'] : '';

		if ( ! ZET_Guard::allow( $to ) ) {
			return;
		}

		$comp     = ! empty( $s['features']['compliance'] );
		$anon_ip  = $comp && ! empty( $s['comp_ip_anon'] );
		$drop_ua  = $comp && ! empty( $s['comp_drop_ua'] );
		$drop_geo = $comp && ! empty( $s['comp_drop_geo'] );
		$fields = isset( $s['fields'] ) && is_array( $s['fields'] ) ? $s['fields'] : array();
		$geo    = '';
		if ( ! $drop_geo && in_array( 'geo', $fields, true ) && 'off' !== ( isset( $s['geo_mode'] ) ? $s['geo_mode'] : 'builtin' ) ) {
			$geo = ZET_Geo::lookup( $ip );
		}

		$event = array(
			'token'     => isset( $rec['token'] ) ? $rec['token'] : '',
			'type'      => 'click',
			'url'       => isset( $rec['url'] ) ? $rec['url'] : '',
			'time'      => current_time( 'mysql' ),
			'timestamp' => time(),
			'to'        => $to,
			'subject'   => isset( $rec['subject'] ) ? $rec['subject'] : '',
			'ip'        => $anon_ip ? ZET_Guard::anon_ip( $ip ) : $ip,
			'geo'       => $geo,
			'device'    => $par['device'],
			'os'        => $par['os'],
			'browser'   => $par['browser'],
			'ua'        => $drop_ua ? '' : $ua,
			'referer'   => isset( $_SERVER['HTTP_REFERER'] ) ? substr( (string) wp_unslash( $_SERVER['HTTP_REFERER'] ), 0, 250 ) : '', // phpcs:ignore
		);

		$verdict = ZET_Guard::rate( $ip );
		if ( 'limited' === $verdict ) {
			ZET_Guard::log_suspect( 'click', $event, $ip, $ua );
			if ( 'block' === ( isset( $s['ratelimit_action'] ) ? $s['ratelimit_action'] : 'log' ) ) {
				return;
			}
		}

		ZET_Storage::save( $event );
		ZET_Notify::dispatch( 'click', $event );
	}
}
