<?php
/**
 * 通知中心：把「打开 / 点击 / 疑似刷流量」等事件实时推送到多个渠道。
 * 渠道均可独立开关：邮件 / 自定义 Webhook / 企业微信机器人 / Server酱 / Bark / Telegram / QQ机器人 Webhook。
 * 短信等其它服务 → 用「自定义 Webhook」对接其 API。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ZET_Notify {

	public static function channels() {
		return array(
			'email'      => '邮件',
			'webhook'    => '自定义 Webhook',
			'wecom'      => '企业微信机器人',
			'serverchan' => 'Server酱（方糖）',
			'bark'       => 'Bark（iOS）',
			'telegram'   => 'Telegram',
			'qq'         => 'QQ 机器人 Webhook',
		);
	}

	public static function events() {
		return array(
			'open'      => '邮件被打开',
			'click'     => '链接被点击',
			'ratelimit' => '疑似刷流量',
		);
	}

	public static function title( $event ) {
		$map = array(
			'open'      => '📬 邮件被打开',
			'click'     => '🔗 链接被点击',
			'ratelimit' => '⚠️ 疑似刷流量',
		);
		return isset( $map[ $event ] ) ? $map[ $event ] : '📧 邮件追踪';
	}

	/** 组装文本内容 */
	public static function text( $event, $d ) {
		$line = function ( $k, $v ) {
			return ( '' === $v || null === $v ) ? '' : $k . '：' . $v . "\n";
		};
		$t = '';
		if ( 'click' === $event ) {
			$t .= $line( '链接', isset( $d['url'] ) ? $d['url'] : '' );
			$t .= $line( '收件人', isset( $d['to'] ) ? $d['to'] : '' );
			$t .= $line( '主题', isset( $d['subject'] ) ? $d['subject'] : '' );
			$t .= $line( '时间', isset( $d['time'] ) ? $d['time'] : '' );
			$t .= $line( 'IP', isset( $d['ip'] ) ? $d['ip'] : '' );
			$t .= $line( '归属地', isset( $d['geo'] ) ? $d['geo'] : '' );
			$t .= $line( '设备', trim( ( isset( $d['device'] ) ? $d['device'] : '' ) . ' / ' . ( isset( $d['os'] ) ? $d['os'] : '' ) . ' / ' . ( isset( $d['browser'] ) ? $d['browser'] : '' ), ' /' ) );
		} elseif ( 'ratelimit' === $event ) {
			$t .= $line( '原因', isset( $d['reason'] ) ? $d['reason'] : '同一 IP 短时间多次打开' );
			$t .= $line( 'IP', isset( $d['ip'] ) ? $d['ip'] : '' );
			$t .= $line( '收件人', isset( $d['to'] ) ? $d['to'] : '' );
			$t .= $line( '时间', isset( $d['time'] ) ? $d['time'] : '' );
		} else { // open
			$t .= $line( '收件人', isset( $d['to'] ) ? $d['to'] : '' );
			$t .= $line( '主题', isset( $d['subject'] ) ? $d['subject'] : '' );
			$t .= $line( '时间', isset( $d['time'] ) ? $d['time'] : '' );
			$t .= $line( 'IP', isset( $d['ip'] ) ? $d['ip'] : '' );
			$t .= $line( '归属地', isset( $d['geo'] ) ? $d['geo'] : '' );
			$t .= $line( '设备', trim( ( isset( $d['device'] ) ? $d['device'] : '' ) . ' / ' . ( isset( $d['os'] ) ? $d['os'] : '' ) . ' / ' . ( isset( $d['browser'] ) ? $d['browser'] : '' ), ' /' ) );
		}
		return trim( $t );
	}

	/** 事件分发入口 */
	public static function dispatch( $event, $data ) {
		$s = zet_get_option();
		if ( empty( $s['features']['notify'] ) ) {
			return;
		}
		$evs = isset( $s['notify_events'] ) ? (array) $s['notify_events'] : array();
		if ( ! in_array( $event, $evs, true ) ) {
			return;
		}

		// 节流：同一 token + 事件，min_interval 秒内只通知一次
		$interval = intval( isset( $s['notify_min_interval'] ) ? $s['notify_min_interval'] : 0 );
		$key      = 'zet_nt_' . md5( ( isset( $data['token'] ) ? $data['token'] : '' ) . '|' . $event );
		if ( $interval > 0 && get_transient( $key ) ) {
			return;
		}
		if ( $interval > 0 ) {
			set_transient( $key, 1, $interval );
		}

		$title = self::title( $event );
		$text  = self::text( $event, $data );
		$chs   = isset( $s['notify_channels'] ) ? (array) $s['notify_channels'] : array();

		foreach ( self::channels() as $ch => $label ) {
			if ( empty( $chs[ $ch ] ) ) {
				continue;
			}
			self::send( $ch, $title, $text, $event, $data, $s );
		}
	}

	private static function send( $ch, $title, $text, $event, $data, $s ) {
		switch ( $ch ) {
			case 'email':
				$to = isset( $s['notify_email'] ) ? $s['notify_email'] : get_option( 'admin_email' );
				if ( $to ) {
					wp_mail( $to, '[邮件追踪] ' . $title, $text );
				}
				break;

			case 'webhook':
				$url = isset( $s['notify_webhook_url'] ) ? $s['notify_webhook_url'] : '';
				if ( $url ) {
					wp_remote_post( $url, array(
						'timeout'  => 6,
						'headers'  => array( 'Content-Type' => 'application/json' ),
						'body'     => wp_json_encode( array( 'event' => $event, 'title' => $title, 'text' => $text, 'data' => $data ) ),
					) );
				}
				break;

			case 'wecom':
				$url = isset( $s['notify_wecom_url'] ) ? $s['notify_wecom_url'] : '';
				if ( $url ) {
					wp_remote_post( $url, array(
						'timeout' => 6,
						'headers' => array( 'Content-Type' => 'application/json' ),
						'body'    => wp_json_encode( array( 'msgtype' => 'text', 'text' => array( 'content' => $title . "\n" . $text ) ) ),
					) );
				}
				break;

			case 'serverchan':
				$key = isset( $s['notify_serverchan_key'] ) ? $s['notify_serverchan_key'] : '';
				if ( $key ) {
					wp_remote_post( 'https://sctapi.ftqq.com/' . rawurlencode( $key ) . '.send', array(
						'timeout' => 6,
						'body'    => array( 'title' => $title, 'desp' => $text ),
					) );
				}
				break;

			case 'bark':
				$base = isset( $s['notify_bark_url'] ) ? $s['notify_bark_url'] : '';
				if ( $base ) {
					$base = rtrim( $base, '/' );
					wp_remote_get( $base . '/' . rawurlencode( $title ) . '/' . rawurlencode( $text ), array( 'timeout' => 6 ) );
				}
				break;

			case 'telegram':
				$token = isset( $s['notify_tg_token'] ) ? $s['notify_tg_token'] : '';
				$chat  = isset( $s['notify_tg_chat'] ) ? $s['notify_tg_chat'] : '';
				if ( $token && $chat ) {
					wp_remote_post( 'https://api.telegram.org/bot' . $token . '/sendMessage', array(
						'timeout' => 6,
						'body'    => array( 'chat_id' => $chat, 'text' => $title . "\n" . $text ),
					) );
				}
				break;

			case 'qq':
				$url = isset( $s['notify_qq_url'] ) ? $s['notify_qq_url'] : '';
				if ( $url ) {
					wp_remote_post( $url, array(
						'timeout' => 6,
						'headers' => array( 'Content-Type' => 'application/json' ),
						'body'    => wp_json_encode( array( 'content' => $title . "\n" . $text, 'msg_type' => 'text' ) ),
					) );
				}
				break;
		}
	}
}
