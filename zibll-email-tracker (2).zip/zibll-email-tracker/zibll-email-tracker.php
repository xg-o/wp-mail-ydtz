<?php
/**
 * Plugin Name:       子比主题邮件阅读通知（追踪像素）
 * Plugin URI:        https://fgw.eajk02.icu/
 * Description:       在邮件正文插入 1×1 透明追踪像素并改写链接，记录收件人打开与点击邮件的时间、真实 IP、地理位置、设备、系统、浏览器；支持实时多渠道通知、防刷限流、合规模式与黑白名单。文件/数据库双存储，适配子比主题（zibll）及任何走 wp_mail 的邮件。
 * Version:           2.1.1
 * Requires at least: 5.5
 * Requires PHP:      7.4
 * Author:            行简 / ima软件copilot模式（腾讯WorkBuddy）
 * Author URI:        https://fgw.eajk02.icu/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zibll-email-tracker
 *
 * ─────────────────────────────────────────────────────────────
 *  原理简述
 * ─────────────────────────────────────────────────────────────
 *  1. 发送邮件时，在 HTML 正文末尾插入一张 1×1 透明图片（追踪像素）。
 *  2. 图片 URL 指向本站：  https://本站/track/<token>.gif
 *  3. 收件人打开邮件、客户端加载图片时，请求回到本站 ->
 *     在那一刻拿到对方的真实 IP、地理位置、设备、系统、浏览器、时间。
 *  4. 请求链路：邮件客户端 → GET /track/<token>.gif
 *     → 记录打开事件 → 写入存储 → 后台"打开记录"里展示 / 实时通知。
 *  5. 链接点击追踪（可选）：正文 <a> 改写为 /go/<id>，点击时记录并 302 跳转。
 *
 *  注意："打开" = "至少加载过一次图片"，不等于"认真读完"。
 * ─────────────────────────────────────────────────────────────
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZET_VERSION', '2.1.1' );
define( 'ZET_FILE', __FILE__ );
define( 'ZET_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZET_URL', plugin_dir_url( __FILE__ ) );
define( 'ZET_OPTION', 'zet_settings' );

/* ─────────────────────────────────────────────
 *  默认设置 & 读取设置
 * ───────────────────────────────────────────── */
if ( ! function_exists( 'zet_defaults' ) ) {
	function zet_defaults() {
		return array(
			'enabled'     => 1,                       // 功能总开关
			'auto_inject' => 1,                       // 自动为 wp_mail 注入像素
			'storage'     => 'file',                  // 存储方式：file | db（默认文件）
			'file_path'   => '',                      // 文件存储目录，留空=uploads/zibll-email-tracker
			'file_format' => 'json',                  // 文件格式：json | txt | md | php
			'table_name'  => '',                      // 数据库表名，留空=wp_zet_email_track
			'fields'      => array( 'ip', 'geo', 'device', 'os', 'browser' ), // 记录哪些信息
			'geo_mode'    => 'builtin',               // IP信息获取方式：off | builtin | api
			'geo_preset'  => 'ipapi',                 // api 预设：ipapi | ipinfo | taobao | gaode | custom
			'geo_url'     => '',                      // 自定义接口 URL 模板（含 {ip} / {key}）
			'geo_key'     => '',                      // 接口 Key / Token
			'geo_c_fields'=> array( 'country' => 'country', 'region' => 'region', 'city' => 'city', 'isp' => 'isp' ),
			'keep_days'   => 90,                      // 记录保留天数，0=永久
			'url_mode'    => 'rewrite',               // 追踪地址形式：rewrite | query

			// ── 功能开关（v2.0）──
			'features'    => array(
				'click_track' => 0,   // 链接点击追踪
				'notify'      => 0,   // 实时通知
				'ratelimit'   => 1,   // 防刷限流（默认开）
				'compliance'  => 0,   // 合规模式（IP 匿名化、不存 UA）
				'whitelist'   => 0,   // 黑白名单
			),

			// ── 通知中心 ──
			'notify_events'         => array( 'open' ),
			'notify_channels'       => array( 'email' => 0, 'webhook' => 0, 'wecom' => 0, 'serverchan' => 0, 'bark' => 0, 'telegram' => 0, 'qq' => 0 ),
			'notify_email'          => '',
			'notify_webhook_url'    => '',
			'notify_wecom_url'      => '',
			'notify_serverchan_key' => '',
			'notify_bark_url'       => '',
			'notify_tg_token'       => '',
			'notify_tg_chat'        => '',
			'notify_qq_url'         => '',
			'notify_min_interval'   => 60,

			// ── 点击追踪 ──
			'click_exclude'         => '',

			// ── 安全 / 合规 ──
			'ratelimit_per_ip'      => 20,
			'ratelimit_window'      => 3600,
			'ratelimit_action'      => 'log',      // log | block
			'log_file'              => '',
			// 黑白名单（可同时存在：黑名单优先；白名单启用且非空则仅跟踪白名单）
			'bl_enabled'            => 0,
			'bl_roles'              => array(),
			'bl_emails'             => '',
			'wl_enabled'            => 0,
			'wl_roles'              => array(),
			'wl_emails'             => '',

			// 合规模式（多选）
			'comp_ip_anon'          => 1,   // IP 匿名化（末段归零）
			'comp_drop_ua'          => 1,   // 不记录原始 UA
			'comp_drop_geo'         => 0,   // 不记录地理位置

			// 合规告知文字
			'notice_enable'         => 0,
			'notice_text'           => '本邮件包含用于统计的追踪像素：当您打开邮件或点击链接时，您的打开时间、IP 归属地、设备与浏览器信息可能会被记录。',

			// ── 中继（下一期启用）──
			'relay_url'             => '',
		);
	}
}

if ( ! function_exists( 'zet_get_option' ) ) {
	function zet_get_option( $key = null ) {
		$opt = get_option( ZET_OPTION, array() );
		if ( ! is_array( $opt ) ) {
			$opt = array();
		}
		$opt = wp_parse_args( $opt, zet_defaults() );
		if ( null === $key ) {
			return $opt;
		}
		return isset( $opt[ $key ] ) ? $opt[ $key ] : null;
	}
}

if ( ! function_exists( 'zet_field_labels' ) ) {
	function zet_field_labels() {
		return array(
			'ip'      => '真实IP',
			'geo'     => '地理位置',
			'device'  => '设备',
			'os'      => '系统',
			'browser' => '浏览器',
			'ua'      => 'UA',
		);
	}
}

if ( ! function_exists( 'zet_substr' ) ) {
	function zet_substr( $str, $len ) {
		return function_exists( 'mb_substr' ) ? mb_substr( (string) $str, 0, $len ) : substr( (string) $str, 0, $len );
	}
}

/* ─────────────────────────────────────────────
 *  加载模块
 * ───────────────────────────────────────────── */
require_once ZET_DIR . 'includes/class-zet-ua.php';
require_once ZET_DIR . 'includes/class-zet-geo.php';
require_once ZET_DIR . 'includes/class-zet-storage.php';
require_once ZET_DIR . 'includes/class-zet-stats.php';
require_once ZET_DIR . 'includes/class-zet-notify.php';
require_once ZET_DIR . 'includes/class-zet-guard.php';
require_once ZET_DIR . 'includes/class-zet-click.php';
require_once ZET_DIR . 'includes/class-zet-tracker.php';
require_once ZET_DIR . 'includes/class-zet-dashboard.php';
require_once ZET_DIR . 'includes/class-zet-settings.php';

/* ─────────────────────────────────────────────
 *  激活 / 停用
 * ───────────────────────────────────────────── */
register_activation_hook( __FILE__, array( 'ZET_Tracker', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ZET_Tracker', 'deactivate' ) );

/* ─────────────────────────────────────────────
 *  启动
 * ───────────────────────────────────────────── */
add_action( 'plugins_loaded', function () {
	if ( ! get_option( ZET_OPTION ) ) {
		add_option( ZET_OPTION, zet_defaults() );
	}
	ZET_Tracker::instance();
	ZET_Click::instance();
	if ( is_admin() ) {
		ZET_Settings::instance();
	}
} );

/* 后台插件列表处快捷入口 */
add_filter( 'plugin_action_links_' . plugin_basename( ZET_FILE ), function ( $links ) {
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=zet-settings' ) ) . '">设置</a>';
	$links[] = '<a href="' . esc_url( admin_url( 'admin.php?page=zet-records' ) ) . '">打开记录</a>';
	return $links;
} );
